import{
c as C,Q as v,w as ct,a as mt,b as We,d as ut,e as xt,f as ht,g as Ne,k as pt,s as ft,h as gt,i as bt,j as vt,p as yt,l as jt,m as wt,n as Nt,o as kt,q as St,r as Mt,t as Ct,u as Pt,v as At,x as Et,y as zt,z as Ot,A as Dt,B as qt,C as Tt,D as ke,E as Wt,F as Bt,G as It,H as Rt,I as Lt,J as $t,K as Ft,L as Xt,M as Ht,N as Vt,O as _t,P as Gt,R as Yt,S as Qt,T as Ut,U as Zt,V as Jt,W as Kt,X as Be,Y as ea,Z as ta,_ as aa,$ as sa,a0 as ra,a1 as oa,a2 as na,a3 as ia,a4 as la,a5 as da}
from"./index-m7tqU0Td.js";
import{
a6 as an}
from"./index-m7tqU0Td.js";
import{
j as e}
from"./query-C74lFsw9.js";
import{
r as h}
from"./vendor-D-Q10PB_.js";
import{
S as ca,u as ma,c as ua,a as Ie,b as xa,P as Re,d as ha}
from"./radix-Cqfao8Cg.js";
import"./router-CMYUmfrL.js";
function Le(t){
var s,a,r="";
if(typeof t=="string"||typeof t=="number")r+=t;
else if(typeof t=="object")if(Array.isArray(t)){
var o=t.length;
for(s=0;
s<o;
s++)t[s]&&(a=Le(t[s]))&&(r&&(r+=" "),r+=a)}
else for(a in t)t[a]&&(r&&(r+=" "),r+=a);
return r}
function $e(){
for(var t,s,a=0,r="",o=arguments.length;
a<o;
a++)(t=arguments[a])&&(s=Le(t))&&(r&&(r+=" "),r+=s);
return r}
const ge="-",pa=t=>{
const s=ga(t),{
conflictingClassGroups:a,conflictingClassGroupModifiers:r}
=t;
return{
getClassGroupId:l=>{
const i=l.split(ge);
return i[0]===""&&i.length!==1&&i.shift(),Fe(i,s)||fa(l)}
,getConflictingClassGroupIds:(l,i)=>{
const d=a[l]||[];
return i&&r[l]?[...d,...r[l]]:d}
}
}
,Fe=(t,s)=>{
if(t.length===0)return s.classGroupId;
const a=t[0],r=s.nextPart.get(a),o=r?Fe(t.slice(1),r):void 0;
if(o)return o;
if(s.validators.length===0)return;
const n=t.join(ge);
return s.validators.find(({
validator:l}
)=>l(n))?.classGroupId}
,Se=/^\[(.+)\]$/,fa=t=>{
if(Se.test(t)){
const s=Se.exec(t)[1],a=s?.substring(0,s.indexOf(":"));
if(a)return"arbitrary.."+a}
}
,ga=t=>{
const{
theme:s,prefix:a}
=t,r={
nextPart:new Map,validators:[]}
;
return va(Object.entries(t.classGroups),a).forEach(([n,l])=>{
fe(l,r,n,s)}
),r}
,fe=(t,s,a,r)=>{
t.forEach(o=>{
if(typeof o=="string"){
const n=o===""?s:Me(s,o);
n.classGroupId=a;
return}
if(typeof o=="function"){
if(ba(o)){
fe(o(r),s,a,r);
return}
s.validators.push({
validator:o,classGroupId:a}
);
return}
Object.entries(o).forEach(([n,l])=>{
fe(l,Me(s,n),a,r)}
)}
)}
,Me=(t,s)=>{
let a=t;
return s.split(ge).forEach(r=>{
a.nextPart.has(r)||a.nextPart.set(r,{
nextPart:new Map,validators:[]}
),a=a.nextPart.get(r)}
),a}
,ba=t=>t.isThemeGetter,va=(t,s)=>s?t.map(([a,r])=>{
const o=r.map(n=>typeof n=="string"?s+n:typeof n=="object"?Object.fromEntries(Object.entries(n).map(([l,i])=>[s+l,i])):n);
return[a,o]}
):t,ya=t=>{
if(t<1)return{
get:()=>{
}
,set:()=>{
}
}
;
let s=0,a=new Map,r=new Map;
const o=(n,l)=>{
a.set(n,l),s++,s>t&&(s=0,r=a,a=new Map)}
;
return{
get(n){
let l=a.get(n);
if(l!==void 0)return l;
if((l=r.get(n))!==void 0)return o(n,l),l}
,set(n,l){
a.has(n)?a.set(n,l):o(n,l)}
}
}
,Xe="!",ja=t=>{
const{
separator:s,experimentalParseClassName:a}
=t,r=s.length===1,o=s[0],n=s.length,l=i=>{
const d=[];
let m=0,c=0,u;
for(let y=0;
y<i.length;
y++){
let k=i[y];
if(m===0){
if(k===o&&(r||i.slice(y,y+n)===s)){
d.push(i.slice(c,y)),c=y+n;
continue}
if(k==="/"){
u=y;
continue}
}
k==="["?m++:k==="]"&&m--}
const f=d.length===0?i:i.substring(c),N=f.startsWith(Xe),j=N?f.substring(1):f,w=u&&u>c?u-c:void 0;
return{
modifiers:d,hasImportantModifier:N,baseClassName:j,maybePostfixModifierPosition:w}
}
;
return a?i=>a({
className:i,parseClassName:l}
):l}
,wa=t=>{
if(t.length<=1)return t;
const s=[];
let a=[];
return t.forEach(r=>{
r[0]==="["?(s.push(...a.sort(),r),a=[]):a.push(r)}
),s.push(...a.sort()),s}
,Na=t=>({
cache:ya(t.cacheSize),parseClassName:ja(t),...pa(t)}
),ka=/\s+/,Sa=(t,s)=>{
const{
parseClassName:a,getClassGroupId:r,getConflictingClassGroupIds:o}
=s,n=[],l=t.trim().split(ka);
let i="";
for(let d=l.length-1;
d>=0;
d-=1){
const m=l[d],{
modifiers:c,hasImportantModifier:u,baseClassName:f,maybePostfixModifierPosition:N}
=a(m);
let j=!!N,w=r(j?f.substring(0,N):f);
if(!w){
if(!j){
i=m+(i.length>0?" "+i:i);
continue}
if(w=r(f),!w){
i=m+(i.length>0?" "+i:i);
continue}
j=!1}
const y=wa(c).join(":"),k=u?y+Xe:y,E=k+w;
if(n.includes(E))continue;
n.push(E);
const D=o(w,j);
for(let z=0;
z<D.length;
++z){
const W=D[z];
n.push(k+W)}
i=m+(i.length>0?" "+i:i)}
return i}
;
function Ma(){
let t=0,s,a,r="";
for(;
t<arguments.length;
)(s=arguments[t++])&&(a=He(s))&&(r&&(r+=" "),r+=a);
return r}
const He=t=>{
if(typeof t=="string")return t;
let s,a="";
for(let r=0;
r<t.length;
r++)t[r]&&(s=He(t[r]))&&(a&&(a+=" "),a+=s);
return a}
;
function Ca(t,...s){
let a,r,o,n=l;
function l(d){
const m=s.reduce((c,u)=>u(c),t());
return a=Na(m),r=a.cache.get,o=a.cache.set,n=i,i(d)}
function i(d){
const m=r(d);
if(m)return m;
const c=Sa(d,a);
return o(d,c),c}
return function(){
return n(Ma.apply(null,arguments))}
}
const A=t=>{
const s=a=>a[t]||[];
return s.isThemeGetter=!0,s}
,Ve=/^\[(?:([a-z-]+):)?(.+)\]$/i,Pa=/^\d+\/\d+$/,Aa=new Set(["px","full","screen"]),Ea=/^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,za=/\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,Oa=/^(rgba?|hsla?|hwb|(ok)?(lab|lch))\(.+\)$/,Da=/^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,qa=/^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,H=t=>K(t)||Aa.has(t)||Pa.test(t),_=t=>ae(t,"length",Fa),K=t=>!!t&&!Number.isNaN(Number(t)),pe=t=>ae(t,"number",K),re=t=>!!t&&Number.isInteger(Number(t)),Ta=t=>t.endsWith("%")&&K(t.slice(0,-1)),b=t=>Ve.test(t),G=t=>Ea.test(t),Wa=new Set(["length","size","percentage"]),Ba=t=>ae(t,Wa,_e),Ia=t=>ae(t,"position",_e),Ra=new Set(["image","url"]),La=t=>ae(t,Ra,Ha),$a=t=>ae(t,"",Xa),oe=()=>!0,ae=(t,s,a)=>{
const r=Ve.exec(t);
return r?r[1]?typeof s=="string"?r[1]===s:s.has(r[1]):a(r[2]):!1}
,Fa=t=>za.test(t)&&!Oa.test(t),_e=()=>!1,Xa=t=>Da.test(t),Ha=t=>qa.test(t),Va=()=>{
const t=A("colors"),s=A("spacing"),a=A("blur"),r=A("brightness"),o=A("borderColor"),n=A("borderRadius"),l=A("borderSpacing"),i=A("borderWidth"),d=A("contrast"),m=A("grayscale"),c=A("hueRotate"),u=A("invert"),f=A("gap"),N=A("gradientColorStops"),j=A("gradientColorStopPositions"),w=A("inset"),y=A("margin"),k=A("opacity"),E=A("padding"),D=A("saturate"),z=A("scale"),W=A("sepia"),p=A("skew"),S=A("space"),q=A("translate"),g=()=>["auto","contain","none"],B=()=>["auto","hidden","clip","visible","scroll"],I=()=>["auto",b,s],x=()=>[b,s],T=()=>["",H,_],L=()=>["auto",K,b],de=()=>["bottom","center","left","left-bottom","left-top","right","right-bottom","right-top","top"],V=()=>["solid","dashed","dotted","double","none"],Z=()=>["normal","multiply","screen","overlay","darken","lighten","color-dodge","color-burn","hard-light","soft-light","difference","exclusion","hue","saturation","color","luminosity"],he=()=>["start","end","center","between","around","evenly","stretch"],se=()=>["","0",b],we=()=>["auto","avoid","all","avoid-page","page","left","right","column"],X=()=>[K,b];
return{
cacheSize:500,separator:":",theme:{
colors:[oe],spacing:[H,_],blur:["none","",G,b],brightness:X(),borderColor:[t],borderRadius:["none","","full",G,b],borderSpacing:x(),borderWidth:T(),contrast:X(),grayscale:se(),hueRotate:X(),invert:se(),gap:x(),gradientColorStops:[t],gradientColorStopPositions:[Ta,_],inset:I(),margin:I(),opacity:X(),padding:x(),saturate:X(),scale:X(),sepia:se(),skew:X(),space:x(),translate:x()}
,classGroups:{
aspect:[{
aspect:["auto","square","video",b]}
],container:["container"],columns:[{
columns:[G]}
],"break-after":[{
"break-after":we()}
],"break-before":[{
"break-before":we()}
],"break-inside":[{
"break-inside":["auto","avoid","avoid-page","avoid-column"]}
],"box-decoration":[{
"box-decoration":["slice","clone"]}
],box:[{
box:["border","content"]}
],display:["block","inline-block","inline","flex","inline-flex","table","inline-table","table-caption","table-cell","table-column","table-column-group","table-footer-group","table-header-group","table-row-group","table-row","flow-root","grid","inline-grid","contents","list-item","hidden"],float:[{
float:["right","left","none","start","end"]}
],clear:[{
clear:["left","right","both","none","start","end"]}
],isolation:["isolate","isolation-auto"],"object-fit":[{
object:["contain","cover","fill","none","scale-down"]}
],"object-position":[{
object:[...de(),b]}
],overflow:[{
overflow:B()}
],"overflow-x":[{
"overflow-x":B()}
],"overflow-y":[{
"overflow-y":B()}
],overscroll:[{
overscroll:g()}
],"overscroll-x":[{
"overscroll-x":g()}
],"overscroll-y":[{
"overscroll-y":g()}
],position:["static","fixed","absolute","relative","sticky"],inset:[{
inset:[w]}
],"inset-x":[{
"inset-x":[w]}
],"inset-y":[{
"inset-y":[w]}
],start:[{
start:[w]}
],end:[{
end:[w]}
],top:[{
top:[w]}
],right:[{
right:[w]}
],bottom:[{
bottom:[w]}
],left:[{
left:[w]}
],visibility:["visible","invisible","collapse"],z:[{
z:["auto",re,b]}
],basis:[{
basis:I()}
],"flex-direction":[{
flex:["row","row-reverse","col","col-reverse"]}
],"flex-wrap":[{
flex:["wrap","wrap-reverse","nowrap"]}
],flex:[{
flex:["1","auto","initial","none",b]}
],grow:[{
grow:se()}
],shrink:[{
shrink:se()}
],order:[{
order:["first","last","none",re,b]}
],"grid-cols":[{
"grid-cols":[oe]}
],"col-start-end":[{
col:["auto",{
span:["full",re,b]}
,b]}
],"col-start":[{
"col-start":L()}
],"col-end":[{
"col-end":L()}
],"grid-rows":[{
"grid-rows":[oe]}
],"row-start-end":[{
row:["auto",{
span:[re,b]}
,b]}
],"row-start":[{
"row-start":L()}
],"row-end":[{
"row-end":L()}
],"grid-flow":[{
"grid-flow":["row","col","dense","row-dense","col-dense"]}
],"auto-cols":[{
"auto-cols":["auto","min","max","fr",b]}
],"auto-rows":[{
"auto-rows":["auto","min","max","fr",b]}
],gap:[{
gap:[f]}
],"gap-x":[{
"gap-x":[f]}
],"gap-y":[{
"gap-y":[f]}
],"justify-content":[{
justify:["normal",...he()]}
],"justify-items":[{
"justify-items":["start","end","center","stretch"]}
],"justify-self":[{
"justify-self":["auto","start","end","center","stretch"]}
],"align-content":[{
content:["normal",...he(),"baseline"]}
],"align-items":[{
items:["start","end","center","baseline","stretch"]}
],"align-self":[{
self:["auto","start","end","center","stretch","baseline"]}
],"place-content":[{
"place-content":[...he(),"baseline"]}
],"place-items":[{
"place-items":["start","end","center","baseline","stretch"]}
],"place-self":[{
"place-self":["auto","start","end","center","stretch"]}
],p:[{
p:[E]}
],px:[{
px:[E]}
],py:[{
py:[E]}
],ps:[{
ps:[E]}
],pe:[{
pe:[E]}
],pt:[{
pt:[E]}
],pr:[{
pr:[E]}
],pb:[{
pb:[E]}
],pl:[{
pl:[E]}
],m:[{
m:[y]}
],mx:[{
mx:[y]}
],my:[{
my:[y]}
],ms:[{
ms:[y]}
],me:[{
me:[y]}
],mt:[{
mt:[y]}
],mr:[{
mr:[y]}
],mb:[{
mb:[y]}
],ml:[{
ml:[y]}
],"space-x":[{
"space-x":[S]}
],"space-x-reverse":["space-x-reverse"],"space-y":[{
"space-y":[S]}
],"space-y-reverse":["space-y-reverse"],w:[{
w:["auto","min","max","fit","svw","lvw","dvw",b,s]}
],"min-w":[{
"min-w":[b,s,"min","max","fit"]}
],"max-w":[{
"max-w":[b,s,"none","full","min","max","fit","prose",{
screen:[G]}
,G]}
],h:[{
h:[b,s,"auto","min","max","fit","svh","lvh","dvh"]}
],"min-h":[{
"min-h":[b,s,"min","max","fit","svh","lvh","dvh"]}
],"max-h":[{
"max-h":[b,s,"min","max","fit","svh","lvh","dvh"]}
],size:[{
size:[b,s,"auto","min","max","fit"]}
],"font-size":[{
text:["base",G,_]}
],"font-smoothing":["antialiased","subpixel-antialiased"],"font-style":["italic","not-italic"],"font-weight":[{
font:["thin","extralight","light","normal","medium","semibold","bold","extrabold","black",pe]}
],"font-family":[{
font:[oe]}
],"fvn-normal":["normal-nums"],"fvn-ordinal":["ordinal"],"fvn-slashed-zero":["slashed-zero"],"fvn-figure":["lining-nums","oldstyle-nums"],"fvn-spacing":["proportional-nums","tabular-nums"],"fvn-fraction":["diagonal-fractions","stacked-fractions"],tracking:[{
tracking:["tighter","tight","normal","wide","wider","widest",b]}
],"line-clamp":[{
"line-clamp":["none",K,pe]}
],leading:[{
leading:["none","tight","snug","normal","relaxed","loose",H,b]}
],"list-image":[{
"list-image":["none",b]}
],"list-style-type":[{
list:["none","disc","decimal",b]}
],"list-style-position":[{
list:["inside","outside"]}
],"placeholder-color":[{
placeholder:[t]}
],"placeholder-opacity":[{
"placeholder-opacity":[k]}
],"text-alignment":[{
text:["left","center","right","justify","start","end"]}
],"text-color":[{
text:[t]}
],"text-opacity":[{
"text-opacity":[k]}
],"text-decoration":["underline","overline","line-through","no-underline"],"text-decoration-style":[{
decoration:[...V(),"wavy"]}
],"text-decoration-thickness":[{
decoration:["auto","from-font",H,_]}
],"underline-offset":[{
"underline-offset":["auto",H,b]}
],"text-decoration-color":[{
decoration:[t]}
],"text-transform":["uppercase","lowercase","capitalize","normal-case"],"text-overflow":["truncate","text-ellipsis","text-clip"],"text-wrap":[{
text:["wrap","nowrap","balance","pretty"]}
],indent:[{
indent:x()}
],"vertical-align":[{
align:["baseline","top","middle","bottom","text-top","text-bottom","sub","super",b]}
],whitespace:[{
whitespace:["normal","nowrap","pre","pre-line","pre-wrap","break-spaces"]}
],break:[{
break:["normal","words","all","keep"]}
],hyphens:[{
hyphens:["none","manual","auto"]}
],content:[{
content:["none",b]}
],"bg-attachment":[{
bg:["fixed","local","scroll"]}
],"bg-clip":[{
"bg-clip":["border","padding","content","text"]}
],"bg-opacity":[{
"bg-opacity":[k]}
],"bg-origin":[{
"bg-origin":["border","padding","content"]}
],"bg-position":[{
bg:[...de(),Ia]}
],"bg-repeat":[{
bg:["no-repeat",{
repeat:["","x","y","round","space"]}
]}
],"bg-size":[{
bg:["auto","cover","contain",Ba]}
],"bg-image":[{
bg:["none",{
"gradient-to":["t","tr","r","br","b","bl","l","tl"]}
,La]}
],"bg-color":[{
bg:[t]}
],"gradient-from-pos":[{
from:[j]}
],"gradient-via-pos":[{
via:[j]}
],"gradient-to-pos":[{
to:[j]}
],"gradient-from":[{
from:[N]}
],"gradient-via":[{
via:[N]}
],"gradient-to":[{
to:[N]}
],rounded:[{
rounded:[n]}
],"rounded-s":[{
"rounded-s":[n]}
],"rounded-e":[{
"rounded-e":[n]}
],"rounded-t":[{
"rounded-t":[n]}
],"rounded-r":[{
"rounded-r":[n]}
],"rounded-b":[{
"rounded-b":[n]}
],"rounded-l":[{
"rounded-l":[n]}
],"rounded-ss":[{
"rounded-ss":[n]}
],"rounded-se":[{
"rounded-se":[n]}
],"rounded-ee":[{
"rounded-ee":[n]}
],"rounded-es":[{
"rounded-es":[n]}
],"rounded-tl":[{
"rounded-tl":[n]}
],"rounded-tr":[{
"rounded-tr":[n]}
],"rounded-br":[{
"rounded-br":[n]}
],"rounded-bl":[{
"rounded-bl":[n]}
],"border-w":[{
border:[i]}
],"border-w-x":[{
"border-x":[i]}
],"border-w-y":[{
"border-y":[i]}
],"border-w-s":[{
"border-s":[i]}
],"border-w-e":[{
"border-e":[i]}
],"border-w-t":[{
"border-t":[i]}
],"border-w-r":[{
"border-r":[i]}
],"border-w-b":[{
"border-b":[i]}
],"border-w-l":[{
"border-l":[i]}
],"border-opacity":[{
"border-opacity":[k]}
],"border-style":[{
border:[...V(),"hidden"]}
],"divide-x":[{
"divide-x":[i]}
],"divide-x-reverse":["divide-x-reverse"],"divide-y":[{
"divide-y":[i]}
],"divide-y-reverse":["divide-y-reverse"],"divide-opacity":[{
"divide-opacity":[k]}
],"divide-style":[{
divide:V()}
],"border-color":[{
border:[o]}
],"border-color-x":[{
"border-x":[o]}
],"border-color-y":[{
"border-y":[o]}
],"border-color-s":[{
"border-s":[o]}
],"border-color-e":[{
"border-e":[o]}
],"border-color-t":[{
"border-t":[o]}
],"border-color-r":[{
"border-r":[o]}
],"border-color-b":[{
"border-b":[o]}
],"border-color-l":[{
"border-l":[o]}
],"divide-color":[{
divide:[o]}
],"outline-style":[{
outline:["",...V()]}
],"outline-offset":[{
"outline-offset":[H,b]}
],"outline-w":[{
outline:[H,_]}
],"outline-color":[{
outline:[t]}
],"ring-w":[{
ring:T()}
],"ring-w-inset":["ring-inset"],"ring-color":[{
ring:[t]}
],"ring-opacity":[{
"ring-opacity":[k]}
],"ring-offset-w":[{
"ring-offset":[H,_]}
],"ring-offset-color":[{
"ring-offset":[t]}
],shadow:[{
shadow:["","inner","none",G,$a]}
],"shadow-color":[{
shadow:[oe]}
],opacity:[{
opacity:[k]}
],"mix-blend":[{
"mix-blend":[...Z(),"plus-lighter","plus-darker"]}
],"bg-blend":[{
"bg-blend":Z()}
],filter:[{
filter:["","none"]}
],blur:[{
blur:[a]}
],brightness:[{
brightness:[r]}
],contrast:[{
contrast:[d]}
],"drop-shadow":[{
"drop-shadow":["","none",G,b]}
],grayscale:[{
grayscale:[m]}
],"hue-rotate":[{
"hue-rotate":[c]}
],invert:[{
invert:[u]}
],saturate:[{
saturate:[D]}
],sepia:[{
sepia:[W]}
],"backdrop-filter":[{
"backdrop-filter":["","none"]}
],"backdrop-blur":[{
"backdrop-blur":[a]}
],"backdrop-brightness":[{
"backdrop-brightness":[r]}
],"backdrop-contrast":[{
"backdrop-contrast":[d]}
],"backdrop-grayscale":[{
"backdrop-grayscale":[m]}
],"backdrop-hue-rotate":[{
"backdrop-hue-rotate":[c]}
],"backdrop-invert":[{
"backdrop-invert":[u]}
],"backdrop-opacity":[{
"backdrop-opacity":[k]}
],"backdrop-saturate":[{
"backdrop-saturate":[D]}
],"backdrop-sepia":[{
"backdrop-sepia":[W]}
],"border-collapse":[{
border:["collapse","separate"]}
],"border-spacing":[{
"border-spacing":[l]}
],"border-spacing-x":[{
"border-spacing-x":[l]}
],"border-spacing-y":[{
"border-spacing-y":[l]}
],"table-layout":[{
table:["auto","fixed"]}
],caption:[{
caption:["top","bottom"]}
],transition:[{
transition:["none","all","","colors","opacity","shadow","transform",b]}
],duration:[{
duration:X()}
],ease:[{
ease:["linear","in","out","in-out",b]}
],delay:[{
delay:X()}
],animate:[{
animate:["none","spin","ping","pulse","bounce",b]}
],transform:[{
transform:["","gpu","none"]}
],scale:[{
scale:[z]}
],"scale-x":[{
"scale-x":[z]}
],"scale-y":[{
"scale-y":[z]}
],rotate:[{
rotate:[re,b]}
],"translate-x":[{
"translate-x":[q]}
],"translate-y":[{
"translate-y":[q]}
],"skew-x":[{
"skew-x":[p]}
],"skew-y":[{
"skew-y":[p]}
],"transform-origin":[{
origin:["center","top","top-right","right","bottom-right","bottom","bottom-left","left","top-left",b]}
],accent:[{
accent:["auto",t]}
],appearance:[{
appearance:["none","auto"]}
],cursor:[{
cursor:["auto","default","pointer","wait","text","move","help","not-allowed","none","context-menu","progress","cell","crosshair","vertical-text","alias","copy","no-drop","grab","grabbing","all-scroll","col-resize","row-resize","n-resize","e-resize","s-resize","w-resize","ne-resize","nw-resize","se-resize","sw-resize","ew-resize","ns-resize","nesw-resize","nwse-resize","zoom-in","zoom-out",b]}
],"caret-color":[{
caret:[t]}
],"pointer-events":[{
"pointer-events":["none","auto"]}
],resize:[{
resize:["none","y","x",""]}
],"scroll-behavior":[{
scroll:["auto","smooth"]}
],"scroll-m":[{
"scroll-m":x()}
],"scroll-mx":[{
"scroll-mx":x()}
],"scroll-my":[{
"scroll-my":x()}
],"scroll-ms":[{
"scroll-ms":x()}
],"scroll-me":[{
"scroll-me":x()}
],"scroll-mt":[{
"scroll-mt":x()}
],"scroll-mr":[{
"scroll-mr":x()}
],"scroll-mb":[{
"scroll-mb":x()}
],"scroll-ml":[{
"scroll-ml":x()}
],"scroll-p":[{
"scroll-p":x()}
],"scroll-px":[{
"scroll-px":x()}
],"scroll-py":[{
"scroll-py":x()}
],"scroll-ps":[{
"scroll-ps":x()}
],"scroll-pe":[{
"scroll-pe":x()}
],"scroll-pt":[{
"scroll-pt":x()}
],"scroll-pr":[{
"scroll-pr":x()}
],"scroll-pb":[{
"scroll-pb":x()}
],"scroll-pl":[{
"scroll-pl":x()}
],"snap-align":[{
snap:["start","end","center","align-none"]}
],"snap-stop":[{
snap:["normal","always"]}
],"snap-type":[{
snap:["none","x","y","both"]}
],"snap-strictness":[{
snap:["mandatory","proximity"]}
],touch:[{
touch:["auto","none","manipulation"]}
],"touch-x":[{
"touch-pan":["x","left","right"]}
],"touch-y":[{
"touch-pan":["y","up","down"]}
],"touch-pz":["touch-pinch-zoom"],select:[{
select:["none","text","all","auto"]}
],"will-change":[{
"will-change":["auto","scroll","contents","transform",b]}
],fill:[{
fill:[t,"none"]}
],"stroke-w":[{
stroke:[H,_,pe]}
],stroke:[{
stroke:[t,"none"]}
],sr:["sr-only","not-sr-only"],"forced-color-adjust":[{
"forced-color-adjust":["auto","none"]}
]}
,conflictingClassGroups:{
overflow:["overflow-x","overflow-y"],overscroll:["overscroll-x","overscroll-y"],inset:["inset-x","inset-y","start","end","top","right","bottom","left"],"inset-x":["right","left"],"inset-y":["top","bottom"],flex:["basis","grow","shrink"],gap:["gap-x","gap-y"],p:["px","py","ps","pe","pt","pr","pb","pl"],px:["pr","pl"],py:["pt","pb"],m:["mx","my","ms","me","mt","mr","mb","ml"],mx:["mr","ml"],my:["mt","mb"],size:["w","h"],"font-size":["leading"],"fvn-normal":["fvn-ordinal","fvn-slashed-zero","fvn-figure","fvn-spacing","fvn-fraction"],"fvn-ordinal":["fvn-normal"],"fvn-slashed-zero":["fvn-normal"],"fvn-figure":["fvn-normal"],"fvn-spacing":["fvn-normal"],"fvn-fraction":["fvn-normal"],"line-clamp":["display","overflow"],rounded:["rounded-s","rounded-e","rounded-t","rounded-r","rounded-b","rounded-l","rounded-ss","rounded-se","rounded-ee","rounded-es","rounded-tl","rounded-tr","rounded-br","rounded-bl"],"rounded-s":["rounded-ss","rounded-es"],"rounded-e":["rounded-se","rounded-ee"],"rounded-t":["rounded-tl","rounded-tr"],"rounded-r":["rounded-tr","rounded-br"],"rounded-b":["rounded-br","rounded-bl"],"rounded-l":["rounded-tl","rounded-bl"],"border-spacing":["border-spacing-x","border-spacing-y"],"border-w":["border-w-s","border-w-e","border-w-t","border-w-r","border-w-b","border-w-l"],"border-w-x":["border-w-r","border-w-l"],"border-w-y":["border-w-t","border-w-b"],"border-color":["border-color-s","border-color-e","border-color-t","border-color-r","border-color-b","border-color-l"],"border-color-x":["border-color-r","border-color-l"],"border-color-y":["border-color-t","border-color-b"],"scroll-m":["scroll-mx","scroll-my","scroll-ms","scroll-me","scroll-mt","scroll-mr","scroll-mb","scroll-ml"],"scroll-mx":["scroll-mr","scroll-ml"],"scroll-my":["scroll-mt","scroll-mb"],"scroll-p":["scroll-px","scroll-py","scroll-ps","scroll-pe","scroll-pt","scroll-pr","scroll-pb","scroll-pl"],"scroll-px":["scroll-pr","scroll-pl"],"scroll-py":["scroll-pt","scroll-pb"],touch:["touch-x","touch-y","touch-pz"],"touch-x":["touch"],"touch-y":["touch"],"touch-pz":["touch"]}
,conflictingClassGroupModifiers:{
"font-size":["leading"]}
}
}
,_a=Ca(Va);
function te(...t){
return _a($e(t))}
const O=({
children:t,onClick:s,variant:a="primary",disabled:r=!1,className:o,type:n="button"}
)=>{
const l="w-full py-4 px-6 rounded-xl font-semibold text-base transition-all duration-200 flex items-center justify-center gap-2",i={
primary:"bg-primary text-primary-foreground hover:bg-primary/90 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed",secondary:"bg-secondary text-secondary-foreground hover:bg-secondary/80 active:scale-[0.98]",outline:"bg-card border-2 border-border text-foreground hover:bg-muted active:scale-[0.98]"}
;
return e.jsx("button",{
type:n,onClick:s,disabled:r,className:te(l,i[a],o),children:t}
)}
;
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ga=C("Activity",[["path",{
d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ya=C("Baby",[["path",{
d:"M9 12h.01",key:"157uk2"}
],["path",{
d:"M15 12h.01",key:"1k8ypt"}
],["path",{
d:"M10 16c.5.3 1.2.5 2 .5s1.5-.2 2-.5",key:"1u7htd"}
],["path",{
d:"M19 6.3a9 9 0 0 1 1.8 3.9 2 2 0 0 1 0 3.6 9 9 0 0 1-17.6 0 2 2 0 0 1 0-3.6A9 9 0 0 1 12 3c2 0 3.5 1.1 3.5 2.5s-.9 2.5-2 2.5c-.8 0-1.5-.4-1.5-1",key:"5yv0yz"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qa=C("Battery",[["rect",{
width:"16",height:"10",x:"2",y:"7",rx:"2",ry:"2",key:"1w10f2"}
],["line",{
x1:"22",x2:"22",y1:"11",y2:"13",key:"4dh1rd"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ge=C("Brain",[["path",{
d:"M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z",key:"l5xja"}
],["path",{
d:"M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z",key:"ep3f8r"}
],["path",{
d:"M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4",key:"1p4c4q"}
],["path",{
d:"M17.599 6.5a3 3 0 0 0 .399-1.375",key:"tmeiqw"}
],["path",{
d:"M6.003 5.125A3 3 0 0 0 6.401 6.5",key:"105sqy"}
],["path",{
d:"M3.477 10.896a4 4 0 0 1 .585-.396",key:"ql3yin"}
],["path",{
d:"M19.938 10.5a4 4 0 0 1 .585.396",key:"1qfode"}
],["path",{
d:"M6 18a4 4 0 0 1-1.967-.516",key:"2e4loj"}
],["path",{
d:"M19.967 17.484A4 4 0 0 1 18 18",key:"159ez6"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ua=C("Briefcase",[["path",{
d:"M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16",key:"jecpp"}
],["rect",{
width:"20",height:"14",x:"2",y:"6",rx:"2",key:"i6l2r4"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ye=C("Calendar",[["path",{
d:"M8 2v4",key:"1cmpym"}
],["path",{
d:"M16 2v4",key:"4m81vk"}
],["rect",{
width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}
],["path",{
d:"M3 10h18",key:"8toen8"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qe=C("Check",[["path",{
d:"M20 6 9 17l-5-5",key:"1gmf2c"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Za=C("ChevronDown",[["path",{
d:"m6 9 6 6 6-6",key:"qrunsl"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ja=C("ChevronRight",[["path",{
d:"m9 18 6-6-6-6",key:"mthhwq"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ka=C("ChevronUp",[["path",{
d:"m18 15-6-6-6 6",key:"153udz"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const es=C("Dumbbell",[["path",{
d:"M14.4 14.4 9.6 9.6",key:"ic80wn"}
],["path",{
d:"M18.657 21.485a2 2 0 1 1-2.829-2.828l-1.767 1.768a2 2 0 1 1-2.829-2.829l6.364-6.364a2 2 0 1 1 2.829 2.829l-1.768 1.767a2 2 0 1 1 2.828 2.829z",key:"nnl7wr"}
],["path",{
d:"m21.5 21.5-1.4-1.4",key:"1f1ice"}
],["path",{
d:"M3.9 3.9 2.5 2.5",key:"1evmna"}
],["path",{
d:"M6.404 12.768a2 2 0 1 1-2.829-2.829l1.768-1.767a2 2 0 1 1-2.828-2.829l2.828-2.828a2 2 0 1 1 2.829 2.828l1.767-1.768a2 2 0 1 1 2.829 2.829z",key:"yhosts"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ts=C("Ellipsis",[["circle",{
cx:"12",cy:"12",r:"1",key:"41hilf"}
],["circle",{
cx:"19",cy:"12",r:"1",key:"1wjl8i"}
],["circle",{
cx:"5",cy:"12",r:"1",key:"1pcz8c"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ce=C("Flame",[["path",{
d:"M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z",key:"96xj49"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ue=C("Heart",[["path",{
d:"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z",key:"c3ymky"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const as=C("Moon",[["path",{
d:"M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z",key:"a7tn18"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ss=C("Move",[["path",{
d:"M12 2v20",key:"t6zp3m"}
],["path",{
d:"m15 19-3 3-3-3",key:"11eu04"}
],["path",{
d:"m19 9 3 3-3 3",key:"1mg7y2"}
],["path",{
d:"M2 12h20",key:"9i4pu4"}
],["path",{
d:"m5 9-3 3 3 3",key:"j64kie"}
],["path",{
d:"m9 5 3-3 3 3",key:"l8vdw6"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const rs=C("Pill",[["path",{
d:"m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z",key:"wa1lgi"}
],["path",{
d:"m8.5 8.5 7 7",key:"rvfmvr"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const os=C("Rocket",[["path",{
d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z",key:"m3kijz"}
],["path",{
d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z",key:"1fmvmk"}
],["path",{
d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0",key:"1f8sc4"}
],["path",{
d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5",key:"qeys4"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ns=C("Scale",[["path",{
d:"m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z",key:"7g6ntu"}
],["path",{
d:"m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z",key:"ijws7r"}
],["path",{
d:"M7 21h10",key:"1b0cd5"}
],["path",{
d:"M12 3v18",key:"108xh3"}
],["path",{
d:"M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2",key:"3gwbw2"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const is=C("Shirt",[["path",{
d:"M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z",key:"1wgbhj"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const be=C("Sparkles",[["path",{
d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}
],["path",{
d:"M20 3v4",key:"1olli1"}
],["path",{
d:"M22 5h-4",key:"1gvqau"}
],["path",{
d:"M4 17v2",key:"vumght"}
],["path",{
d:"M5 18H3",key:"zchphs"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ls=C("Target",[["circle",{
cx:"12",cy:"12",r:"10",key:"1mglay"}
],["circle",{
cx:"12",cy:"12",r:"6",key:"1vlfrh"}
],["circle",{
cx:"12",cy:"12",r:"2",key:"1c9p78"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ds=C("TriangleAlert",[["path",{
d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}
],["path",{
d:"M12 9v4",key:"juzpu7"}
],["path",{
d:"M12 17h.01",key:"p32p05"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const cs=C("UserCheck",[["path",{
d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}
],["circle",{
cx:"9",cy:"7",r:"4",key:"nufk8"}
],["polyline",{
points:"16 11 18 13 22 9",key:"1pwet4"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ms=C("User",[["path",{
d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}
],["circle",{
cx:"12",cy:"7",r:"4",key:"17ys0d"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const us=C("Users",[["path",{
d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}
],["circle",{
cx:"9",cy:"7",r:"4",key:"nufk8"}
],["path",{
d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}
],["path",{
d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xs=C("X",[["path",{
d:"M18 6 6 18",key:"1bl5f8"}
],["path",{
d:"m6 6 12 12",key:"d8bk6v"}
]]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ze=C("Zap",[["path",{
d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}
]]),P=({
children:t,onClick:s,selected:a=!1,showArrow:r=!1,showCheckbox:o=!1,icon:n,image:l,description:i,emoji:d,className:m}
)=>e.jsxs("button",{
onClick:s,className:te("w-full rounded-xl bg-card border-2 transition-all duration-200 text-left flex items-center gap-3 quiz-shadow hover:quiz-shadow-lg active:scale-[0.98]",l?"p-2":"p-4",a?"border-primary bg-accent":"border-transparent hover:border-muted-foreground/20",m),children:[l&&e.jsx("div",{
className:"w-16 h-16 rounded-lg overflow-hidden flex-shrink-0",children:e.jsx("img",{
src:l,alt:"",className:"w-full h-full object-cover",loading:"eager",decoding:"async"}
)}
),d&&e.jsx("span",{
className:"text-2xl flex-shrink-0",children:d}
),n&&e.jsx("div",{
className:"w-10 h-10 rounded-lg bg-muted flex items-center justify-center flex-shrink-0 text-primary",children:n}
),e.jsxs("div",{
className:"flex-1 min-w-0",children:[e.jsx("span",{
className:"font-semibold text-foreground block",children:t}
),i&&e.jsx("span",{
className:"text-sm text-muted-foreground mt-0.5 block",children:i}
)]}
),r&&e.jsx(Ja,{
className:"w-5 h-5 text-muted-foreground flex-shrink-0"}
),o&&e.jsx("div",{
className:te("w-6 h-6 rounded-md border-2 flex items-center justify-center flex-shrink-0 transition-colors",a?"bg-primary border-primary":"border-muted-foreground/30"),children:a&&e.jsx(Qe,{
className:"w-4 h-4 text-primary-foreground"}
)}
)]}
),Ce=t=>{
if(typeof window>"u")return!1;
const s=document.createElement("img");
return s.src=t,s.complete&&s.naturalHeight>0}
,ie=({
src:t,alt:s,className:a="",width:r,height:o,priority:n=!1,style:l}
)=>{
const[i,d]=h.useState(()=>Ce(t)),[m,c]=h.useState(t);
return h.useEffect(()=>{
t!==m&&(c(t),Ce(t)?d(!0):d(!1))}
,[t,m]),e.jsxs("div",{
className:`relative overflow-hidden bg-muted ${
a}
`,style:{
...l,minHeight:o||l?.minHeight||"auto"}
,children:[!i&&e.jsx("div",{
className:"absolute inset-0 bg-muted","aria-hidden":"true"}
),e.jsx("img",{
src:t,alt:s,width:r,height:o,loading:n?"eager":"lazy",decoding:"async",fetchPriority:n?"high":"auto",onLoad:()=>d(!0),className:`w-full h-full object-cover ${
i?"opacity-100":"opacity-0"}
`,style:l}
)]}
)}
,uo=({
onContinue:t,onBack:s}
)=>e.jsx(v,{
step:2,totalSteps:35,showProgress:!1,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 flex flex-col items-center justify-start md:justify-center px-4 py-2 md:py-8",children:e.jsxs("div",{
className:"max-w-md w-full text-center",children:[e.jsx(ie,{
src:ct,alt:"Grupo de mulheres praticando exercícios",className:"mb-6 rounded-2xl quiz-shadow-lg w-full",height:256,priority:!0}
),e.jsx("h1",{
className:"text-2xl md:text-3xl font-bold text-foreground mb-2",children:"Elas conseguiram e você também pode"}
),e.jsx("p",{
className:"text-muted-foreground mb-8",children:"Mais de 27 milhões de mulheres já transformaram suas vidas com a Calistenia Asiática"}
),e.jsx(O,{
onClick:t,children:"Continuar"}
)]}
)}
)}
),xo=({
onSelect:t,onBack:s}
)=>e.jsx(v,{
step:3,totalSteps:35,showBack:!0,onBack:s,children:e.jsxs("div",{
className:"flex-1 flex flex-col items-center justify-start px-6 md:px-4 pt-6 md:pt-8 pb-6 relative overflow-hidden",children:[e.jsx("div",{
className:"text-center mb-6 md:mb-6 w-full max-w-md relative z-10 px-2",children:e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground",children:"Você já experimentou exercícios de calistenia?"}
)}
),e.jsxs("div",{
className:"relative w-full max-w-md min-h-[450px] md:min-h-0",children:[e.jsx("div",{
className:"absolute right-[-80px] top-[-100px] w-[480px] md:right-[-80px] md:top-[-80px] md:w-[260px] lg:right-[-60px] lg:w-[300px] pointer-events-none z-0",children:e.jsx("img",{
src:mt,alt:"Mulher fitness",className:"w-full h-auto object-contain",loading:"eager",decoding:"async",fetchPriority:"high"}
)}
),e.jsxs("div",{
className:"space-y-3 w-[60%] md:w-[65%] relative z-10",children:[e.jsx(P,{
onClick:()=>t("sim"),children:"Sim"}
),e.jsx(P,{
onClick:()=>t("nao"),children:"Não"}
)]}
)]}
)]}
)}
),Pe=t=>typeof t=="boolean"?`${
t}
`:t===0?"0":t,Ae=$e,hs=(t,s)=>a=>{
var r;
if(s?.variants==null)return Ae(t,a?.class,a?.className);
const{
variants:o,defaultVariants:n}
=s,l=Object.keys(o).map(m=>{
const c=a?.[m],u=n?.[m];
if(c===null)return null;
const f=Pe(c)||Pe(u);
return o[m][f]}
),i=a&&Object.entries(a).reduce((m,c)=>{
let[u,f]=c;
return f===void 0||(m[u]=f),m}
,{
}
),d=s==null||(r=s.compoundVariants)===null||r===void 0?void 0:r.reduce((m,c)=>{
let{
class:u,className:f,...N}
=c;
return Object.entries(N).every(j=>{
let[w,y]=j;
return Array.isArray(y)?y.includes({
...n,...i}
[w]):{
...n,...i}
[w]===y}
)?[...m,u,f]:m}
,[]);
return Ae(t,l,d,a?.class,a?.className)}
,ps=hs("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",{
variants:{
variant:{
default:"bg-primary text-primary-foreground hover:bg-primary/90",destructive:"bg-destructive text-destructive-foreground hover:bg-destructive/90",outline:"border border-input bg-background hover:bg-accent hover:text-accent-foreground",secondary:"bg-secondary text-secondary-foreground hover:bg-secondary/80",ghost:"hover:bg-accent hover:text-accent-foreground",link:"text-primary underline-offset-4 hover:underline"}
,size:{
default:"h-10 px-4 py-2",sm:"h-9 rounded-md px-3",lg:"h-11 rounded-md px-8",icon:"h-10 w-10"}
}
,defaultVariants:{
variant:"default",size:"default"}
}
),ve=h.forwardRef(({
className:t,variant:s,size:a,asChild:r=!1,...o}
,n)=>{
const l=r?ca:"button";
return e.jsx(l,{
className:te(ps({
variant:s,size:a,className:t}
)),ref:n,...o}
)}
);
ve.displayName="Button";
const ho=({
onContinue:t,onBack:s}
)=>e.jsxs(v,{
step:4,totalSteps:35,showBack:!0,onBack:s,children:[e.jsx("div",{
className:"flex-1 flex items-start md:items-center justify-start md:justify-center px-6 md:px-12 py-2 md:py-8",children:e.jsxs("div",{
className:"w-full max-w-5xl flex flex-col md:flex-row gap-4 md:gap-12 items-center",children:[e.jsxs("div",{
className:"flex-1 text-center md:text-left",children:[e.jsx("h1",{
className:"text-xl md:text-3xl lg:text-4xl font-bold text-foreground leading-snug md:leading-tight mb-2 md:mb-6",children:"Você já tem a base, mas a Calistenia Asiática é diferente da calistenia comum."}
),e.jsxs("p",{
className:"text-sm md:text-lg text-muted-foreground leading-relaxed",children:["Enquanto o método tradicional foca apenas em força externa, nossa técnica ativa as ",e.jsx("strong",{
className:"text-foreground",children:"fibras profundas"}
),", agindo na musculatura interna, onde eliminamos a ",e.jsx("strong",{
className:"text-foreground",children:"gordura mais difícil de queimar"}
)," e destravamos o seu metabolismo de forma definitiva."]}
)]}
),e.jsx("div",{
className:"w-full md:w-1/2 flex-shrink-0",children:e.jsx("img",{
src:We,alt:"Mulher praticando exercício",className:"w-full h-auto rounded-2xl object-cover"}
)}
)]}
)}
),e.jsx("div",{
className:"fixed bottom-0 left-0 right-0 px-6 pb-4 pt-4",children:e.jsx(ve,{
onClick:t,className:"w-full max-w-md mx-auto flex items-center justify-center py-6 text-base font-semibold uppercase tracking-wide",children:"Continuar"}
)}
)]}
),po=({
onContinue:t,onBack:s}
)=>e.jsxs(v,{
step:4,totalSteps:35,showBack:!0,onBack:s,children:[e.jsx("div",{
className:"flex-1 flex items-center justify-center px-6 md:px-12 py-4 md:py-8",children:e.jsxs("div",{
className:"w-full max-w-5xl flex flex-col md:flex-row gap-4 md:gap-12 items-center",children:[e.jsxs("div",{
className:"flex-1 text-center md:text-left",children:[e.jsx("h1",{
className:"text-xl md:text-3xl lg:text-4xl font-bold text-foreground leading-snug md:leading-tight mb-2 md:mb-6",children:"Não se preocupe, a Calistenia Asiática é perfeita para quem está começando do zero!"}
),e.jsxs("p",{
className:"text-sm md:text-lg text-muted-foreground leading-relaxed",children:["Calistenia significa usar apenas o peso do seu corpo, e nossa técnica simplifica tudo ao focar na ativação das ",e.jsx("strong",{
className:"text-foreground",children:"fibras profundas"}
),". É o caminho mais rápido para você ",e.jsx("strong",{
className:"text-foreground",children:"destravar o metabolismo"}
)," e ",e.jsx("strong",{
className:"text-foreground",children:"secar a barriga"}
)," sem o esforço exaustivo da academia."]}
)]}
),e.jsx("div",{
className:"w-full md:w-1/2 flex-shrink-0",children:e.jsx("img",{
src:We,alt:"Mulher praticando exercício",className:"w-full h-auto rounded-2xl object-cover"}
)}
)]}
)}
),e.jsx("div",{
className:"fixed bottom-0 left-0 right-0 px-6 pb-4 pt-4",children:e.jsx(ve,{
onClick:t,className:"w-full max-w-md mx-auto flex items-center justify-center py-6 text-base font-semibold uppercase tracking-wide",children:"Continuar"}
)}
)]}
),fo=({
onSelect:t,onBack:s}
)=>e.jsx(v,{
step:4,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsxs("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-1 text-center",children:["Qual é seu ",e.jsx("span",{
className:"text-primary",children:"principal objetivo"}
),"?"]}
),e.jsxs("div",{
className:"space-y-3 mt-6",children:[e.jsx(P,{
onClick:()=>t("perder-peso"),icon:e.jsx(ns,{
className:"w-5 h-5"}
),children:"Perder peso"}
),e.jsx(P,{
onClick:()=>t("desenvolver-musculos"),icon:e.jsx(es,{
className:"w-5 h-5"}
),children:"Desenvolver músculos"}
),e.jsx(P,{
onClick:()=>t("manter-peso"),icon:e.jsx(cs,{
className:"w-5 h-5"}
),children:"Manter o peso e ficar em forma"}
),e.jsx(P,{
onClick:()=>t("melhorar-aptidao"),icon:e.jsx(Ze,{
className:"w-5 h-5"}
),children:"Melhorar a aptidão física"}
)]}
)]}
)}
)}
),go=({
onContinue:t,onBack:s}
)=>{
const[a,r]=h.useState([]),o=i=>{
r(d=>d.includes(i)?d.filter(m=>m!==i):[...d,i])}
,n=[{
id:"energia",label:"Aumentar a energia",icon:e.jsx(Qa,{
className:"w-5 h-5"}
)}
,{
id:"sono",label:"Melhorar o sono",icon:e.jsx(as,{
className:"w-5 h-5"}
)}
,{
id:"estresse",label:"Reduzir o estresse",icon:e.jsx(Ge,{
className:"w-5 h-5"}
)}
,{
id:"postura",label:"Melhorar a postura e a mobilidade",icon:e.jsx(ss,{
className:"w-5 h-5"}
)}
,{
id:"flexibilidade",label:"Desenvolver flexibilidade",icon:e.jsx(be,{
className:"w-5 h-5"}
)}
],l=e.jsx(O,{
onClick:()=>t(a),disabled:a.length===0,children:"Continuar"}
);
return e.jsx(v,{
step:5,totalSteps:35,showBack:!0,onBack:s,stickyFooter:l,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-1 text-center",children:"O que mais você espera alcançar com este plano?"}
),e.jsx("p",{
className:"text-muted-foreground mb-6 text-center",children:"Pode escolher várias opções"}
),e.jsx("div",{
className:"space-y-3",children:n.map(i=>e.jsx(P,{
onClick:()=>o(i.id),selected:a.includes(i.id),showCheckbox:!0,icon:i.icon,children:i.label}
,i.id))}
)]}
)}
)}
)}
;
function fs(t){
const s=h.useRef({
value:t,previous:t}
);
return h.useMemo(()=>(s.current.value!==t&&(s.current.previous=s.current.value,s.current.value=t),s.current.previous),[t])}
function gs(t){
const[s,a]=h.useState(void 0);
return ma(()=>{
if(t){
a({
width:t.offsetWidth,height:t.offsetHeight}
);
const r=new ResizeObserver(o=>{
if(!Array.isArray(o)||!o.length)return;
const n=o[0];
let l,i;
if("borderBoxSize"in n){
const d=n.borderBoxSize,m=Array.isArray(d)?d[0]:d;
l=m.inlineSize,i=m.blockSize}
else l=t.offsetWidth,i=t.offsetHeight;
a({
width:l,height:i}
)}
);
return r.observe(t,{
box:"border-box"}
),()=>r.unobserve(t)}
else a(void 0)}
,[t]),s}
var ue="Switch",[bs,bo]=ua(ue),[vs,ys]=bs(ue),Je=h.forwardRef((t,s)=>{
const{
__scopeSwitch:a,name:r,checked:o,defaultChecked:n,required:l,disabled:i,value:d="on",onCheckedChange:m,form:c,...u}
=t,[f,N]=h.useState(null),j=Ie(s,D=>N(D)),w=h.useRef(!1),y=f?c||!!f.closest("form"):!0,[k,E]=xa({
prop:o,defaultProp:n??!1,onChange:m,caller:ue}
);
return e.jsxs(vs,{
scope:a,checked:k,disabled:i,children:[e.jsx(Re.button,{
type:"button",role:"switch","aria-checked":k,"aria-required":l,"data-state":at(k),"data-disabled":i?"":void 0,disabled:i,value:d,...u,ref:j,onClick:ha(t.onClick,D=>{
E(z=>!z),y&&(w.current=D.isPropagationStopped(),w.current||D.stopPropagation())}
)}
),y&&e.jsx(tt,{
control:f,bubbles:!w.current,name:r,value:d,checked:k,required:l,disabled:i,form:c,style:{
transform:"translateX(-100%)"}
}
)]}
)}
);
Je.displayName=ue;
var Ke="SwitchThumb",et=h.forwardRef((t,s)=>{
const{
__scopeSwitch:a,...r}
=t,o=ys(Ke,a);
return e.jsx(Re.span,{
"data-state":at(o.checked),"data-disabled":o.disabled?"":void 0,...r,ref:s}
)}
);
et.displayName=Ke;
var js="SwitchBubbleInput",tt=h.forwardRef(({
__scopeSwitch:t,control:s,checked:a,bubbles:r=!0,...o}
,n)=>{
const l=h.useRef(null),i=Ie(l,n),d=fs(a),m=gs(s);
return h.useEffect(()=>{
const c=l.current;
if(!c)return;
const u=window.HTMLInputElement.prototype,N=Object.getOwnPropertyDescriptor(u,"checked").set;
if(d!==a&&N){
const j=new Event("click",{
bubbles:r}
);
N.call(c,a),c.dispatchEvent(j)}
}
,[d,a,r]),e.jsx("input",{
type:"checkbox","aria-hidden":!0,defaultChecked:a,...o,tabIndex:-1,ref:i,style:{
...o.style,...m,position:"absolute",pointerEvents:"none",opacity:0,margin:0}
}
)}
);
tt.displayName=js;
function at(t){
return t?"checked":"unchecked"}
var st=Je,ws=et;
const rt=h.forwardRef(({
className:t,...s}
,a)=>e.jsx(st,{
className:te("peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors data-[state=checked]:bg-primary data-[state=unchecked]:bg-input focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50",t),...s,ref:a,children:e.jsx(ws,{
className:te("pointer-events-none block h-5 w-5 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0")}
)}
));
rt.displayName=st.displayName;
const vo=({
onContinue:t,onBack:s}
)=>{
const[a,r]=h.useState([]),[o,n]=h.useState(!1),l=[{
id:"queixo",label:"Queixo duplo",image:ut}
,{
id:"bracos",label:"Braços flácidos",image:xt}
,{
id:"seios",label:"Seios caídos",image:ht}
,{
id:"barriga",label:"Gordura da barriga",image:Ne}
,{
id:"joelhos",label:"Gordura nos joelhos",image:pt}
,{
id:"traseiro",label:"Traseiro de alforje",image:ft}
,{
id:"nadegas",label:"Nádegas flácidas",image:gt}
,{
id:"coxa",label:"Parte interna da coxa",image:Ne}
],i=c=>{
n(!1),r(u=>u.includes(c)?u.filter(f=>f!==c):[...u,c])}
,d=c=>{
n(c),r(c?l.map(u=>u.id):[])}
,m=e.jsx(O,{
onClick:()=>t(a),disabled:a.length===0,children:"Próximo passo"}
);
return e.jsx(v,{
step:8,totalSteps:36,showBack:!0,onBack:s,stickyFooter:m,children:e.jsx("div",{
className:"flex-1 px-4 py-6 overflow-y-auto",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-1 text-center",children:"Quais são as zonas que mais a preocupam?"}
),e.jsx("p",{
className:"text-muted-foreground mb-6 text-center",children:"Por favor, selecione todas as opções aplicáveis"}
),e.jsxs("div",{
className:"flex items-center gap-3 mb-4",children:[e.jsx(rt,{
checked:o,onCheckedChange:d}
),e.jsx("span",{
className:"font-medium text-foreground",children:"Melhorar o corpo inteiro"}
)]}
),e.jsx("div",{
className:"space-y-3",children:l.map(c=>e.jsx(P,{
onClick:()=>i(c.id),selected:a.includes(c.id),showCheckbox:!0,image:c.image,children:c.label}
,c.id))}
)]}
)}
)}
)}
,yo=({
onContinue:t,onBack:s}
)=>{
const[a,r]=h.useState([]),o=[{
id:"barriga",label:"Barriga",image:bt}
,{
id:"bunda",label:"Bunda",image:vt}
,{
id:"pernas",label:"Pernas",image:yt}
,{
id:"peito",label:"Peito",image:jt}
,{
id:"bracos",label:"Braços",image:wt}
,{
id:"costas",label:"Costas",image:Nt}
],n=i=>{
r(d=>d.includes(i)?d.filter(m=>m!==i):[...d,i])}
,l=e.jsx(O,{
onClick:()=>t(a),disabled:a.length===0,children:"Próximo passo"}
);
return e.jsx(v,{
step:9,totalSteps:36,showBack:!0,onBack:s,stickyFooter:l,children:e.jsx("div",{
className:"flex-1 px-4 py-6 pb-32 md:pb-48 overflow-y-auto",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-1 text-center",children:"Quais são as suas zonas alvo?"}
),e.jsx("p",{
className:"text-muted-foreground mb-6 text-center",children:"Escolha todas as opções aplicáveis"}
),e.jsx("div",{
className:"space-y-3",children:o.map(i=>e.jsx(P,{
onClick:()=>n(i.id),selected:a.includes(i.id),showCheckbox:!0,image:i.image,children:i.label}
,i.id))}
)]}
)}
)}
)}
,jo=({
onContinue:t,onBack:s}
)=>e.jsxs(v,{
step:9,totalSteps:36,showBack:!0,onBack:s,children:[e.jsx("div",{
className:"flex-1 px-4 py-2 md:py-6 pb-16 overflow-y-auto",children:e.jsxs("div",{
className:"max-w-md mx-auto text-center",children:[e.jsx("div",{
className:"mb-2 md:mb-3 flex justify-center",children:e.jsx("img",{
src:kt,alt:"Mulher fazendo sinal de OK",className:"w-[80%] md:w-[70%] object-contain rounded-2xl quiz-shadow-lg",loading:"eager",decoding:"async",fetchPriority:"high"}
)}
),e.jsxs("h1",{
className:"text-base md:text-lg font-bold text-foreground mb-2",children:["Apenas 7 minutos por dia — transformarão seu corpo e"," ",e.jsx("span",{
className:"text-primary",children:"destravarão o seu metabolismo"}
)," ","sem o esforço exaustivo da academia!"]}
),e.jsx("p",{
className:"text-muted-foreground text-sm leading-relaxed",children:"O Protocolo de Calistenia Asiática utiliza ativações de fibras profundas para derreter a gordura acumulada e chapar a barriga, agindo onde os exercícios comuns de academia não conseguem chegar, de forma simples e definitiva..."}
)]}
)}
),e.jsx("div",{
className:"fixed bottom-0 left-0 right-0 p-4 bg-background z-50",children:e.jsx("div",{
className:"max-w-md mx-auto",children:e.jsx(O,{
onClick:t,children:"Continuar"}
)}
)}
)]}
),wo=({
onSelect:t,onBack:s}
)=>{
const a=[{
id:"magra",label:"Magra",image:St}
,{
id:"falsa-magra",label:"Falsa Magra",image:Mt}
,{
id:"acima-peso",label:"Acima do peso",image:Ct}
,{
id:"sobrepeso",label:"Sobrepeso",image:Pt}
];
return e.jsx(v,{
step:8,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-4xl mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-6 text-center",children:"Como você descreveria o seu corpo atualmente?"}
),e.jsx("div",{
className:"grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4",children:a.map(r=>e.jsxs("button",{
onClick:()=>t(r.id),className:"bg-card border-2 border-transparent rounded-2xl p-3 transition-all duration-200 quiz-shadow hover:quiz-shadow-lg hover:border-muted-foreground/20 active:scale-[0.98] flex flex-col items-center",children:[e.jsx("div",{
className:"w-full aspect-square rounded-xl overflow-hidden bg-muted mb-3",style:{
minHeight:120}
,children:e.jsx(ie,{
src:r.image,alt:r.label,className:"w-full h-full",style:{
objectFit:"cover",objectPosition:"top"}
}
)}
),e.jsx("span",{
className:"font-semibold text-foreground text-center text-sm md:text-base",children:r.label}
)]}
,r.id))}
)]}
)}
)}
)}
,No=({
onSelect:t,onBack:s}
)=>{
const a=[{
id:"curvilinea",label:"Curvado",image:At}
,{
id:"magro",label:"Magro",image:Et}
,{
id:"em-forma",label:"Em forma",image:zt}
,{
id:"tonificado",label:"Tonificado",image:Ot}
,{
id:"satisfeita",label:"Estou bem com meu corpo",image:Dt}
];
return e.jsx(v,{
step:9,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-6 text-center",children:"Qual é o corpo dos seus sonhos?"}
),e.jsx("div",{
className:"space-y-3",children:a.map(r=>e.jsxs("button",{
onClick:()=>t(r.id),className:"w-full flex items-center gap-3 p-2 rounded-xl bg-card border-2 border-transparent hover:border-muted-foreground/20 transition-all duration-200 quiz-shadow hover:quiz-shadow-lg active:scale-[0.98]",children:[e.jsx("div",{
className:"w-16 h-16 rounded-xl overflow-hidden bg-muted flex-shrink-0",children:e.jsx(ie,{
src:r.image,alt:r.label,className:"w-full h-full",width:64,height:64}
)}
),e.jsx("span",{
className:"font-semibold text-foreground text-left",children:r.label}
)]}
,r.id))}
)]}
)}
)}
)}
,ko=({
onSelect:t,onBack:s}
)=>{
const a=[{
id:"1-2-anos",label:"1 a 2 anos atrás"}
,{
id:"3-5-anos",label:"3 a 5 anos atrás"}
,{
id:"mais-5-anos",label:"Mais de 5 anos atrás"}
,{
id:"nunca",label:"Nunca"}
];
return e.jsx(v,{
step:10,totalSteps:35,showBack:!0,onBack:s,children:e.jsxs("div",{
className:"flex-1 flex flex-col px-4 py-6",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-6 text-center max-w-md mx-auto",children:"Há quanto tempo você estava na melhor forma da sua vida?"}
),e.jsxs("div",{
className:"relative w-full h-[75vh] md:h-[420px]",children:[e.jsx("div",{
className:"absolute right-1/2 top-0 max-w-xs space-y-3",children:a.map(r=>e.jsx(P,{
onClick:()=>t(r.id),children:r.label}
,r.id))}
),e.jsx("img",{
src:qt,alt:"Mulher em forma",className:"absolute left-1/2 top-0 h-full md:h-[400px] object-cover md:object-contain object-top pointer-events-none -translate-x-[30%]",loading:"eager",decoding:"async",fetchPriority:"high"}
)]}
)]}
)}
)}
,So=({
onContinue:t,onBack:s}
)=>{
const[a,r]=h.useState([]),o=i=>{
if(i==="nenhuma"){
r(["nenhuma"]);
return}
r(d=>{
const m=d.filter(c=>c!=="nenhuma");
return m.includes(i)?m.filter(c=>c!==i):[...m,i]}
)}
,n=[{
id:"costas",label:"Costas sensíveis",image:Tt}
,{
id:"joelhos",label:"Joelhos sensíveis",image:ke}
,{
id:"quadril",label:"Quadril sensível",image:Wt}
,{
id:"ombros",label:"Ombros e braços",image:Bt}
,{
id:"panturrilhas",label:"Panturrilhas e tornozelos",image:ke}
,{
id:"nenhuma",label:"Nenhuma das opções acima"}
],l=e.jsx(O,{
onClick:()=>t(a),disabled:a.length===0,children:"Próximo passo"}
);
return e.jsx(v,{
step:12,totalSteps:34,showBack:!0,onBack:s,stickyFooter:l,children:e.jsx("div",{
className:"flex-1 px-4 py-6 overflow-y-auto",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-1 text-center",children:"Você tem dificuldades com algum dos seguintes itens?"}
),e.jsx("p",{
className:"text-muted-foreground mb-6 text-center",children:"Por favor, selecione todas as opções aplicáveis"}
),e.jsx("div",{
className:"space-y-3",children:n.map(i=>e.jsx(P,{
onClick:()=>o(i.id),selected:a.includes(i.id),showCheckbox:!0,image:i.image,children:i.label}
,i.id))}
)]}
)}
)}
)}
,Mo=({
onSelect:t,onBack:s}
)=>{
const a=[{
id:"dor",label:"Sinto dor/Desconforto",emoji:"😔"}
,{
id:"dificuldade",label:"Sinto alguma dificuldade",emoji:"😐"}
,{
id:"confortavel",label:"Sinto-me confortável",emoji:"😊"}
];
return e.jsx(v,{
step:14,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-6 text-center",children:"Você se sente confortável ao se exercitar?"}
),e.jsx("div",{
className:"space-y-3",children:a.map(r=>e.jsx(P,{
onClick:()=>t(r.id),emoji:r.emoji,children:r.label}
,r.id))}
)]}
)}
)}
)}
,Co=({
onContinue:t,onBack:s,comfortLevel:a}
)=>{
const r=a==="dor"||a==="dificuldade";
return e.jsx(v,{
step:15,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto text-center",children:[e.jsx("div",{
className:"mb-6 rounded-2xl overflow-hidden quiz-shadow-lg bg-muted",children:e.jsx("img",{
src:It,alt:"Mulher motivada",className:"w-full object-contain",loading:"eager",decoding:"async",fetchPriority:"high"}
)}
),r?e.jsxs(e.Fragment,{
children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-4",children:"Nós cuidamos de você!"}
),e.jsx("p",{
className:"text-muted-foreground mb-6 text-sm leading-relaxed",children:"A dor não vai te impedir. Adaptaremos seu programa para promover movimentos seguros e suaves."}
)]}
):e.jsxs(e.Fragment,{
children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-4",children:"Isso é ótimo!"}
),e.jsx("p",{
className:"text-muted-foreground mb-6 text-sm leading-relaxed",children:"Você está pronta para seguir em frente - prepare-se para a transformação com a Calistenia Asiática."}
)]}
),e.jsx(O,{
onClick:t,children:"Continuar"}
)]}
)}
)}
)}
,Po=({
onContinue:t,onBack:s}
)=>{
const[a,r]=h.useState(165),[o,n]=h.useState("cm"),l=h.useRef(null),i=h.useRef(!1),d=h.useRef(0),m=h.useRef(165),c=o==="cm"?120:47,u=o==="cm"?220:87,f=14,N=p=>{
i.current=!0,d.current=p,m.current=a}
,j=p=>{
if(!i.current)return;
const q=(d.current-p)/f,g=Math.max(c,Math.min(u,m.current+q));
r(Math.round(g))}
,w=p=>{
p.preventDefault(),N(p.clientX)}
,y=p=>{
N(p.touches[0].clientX)}
;
h.useEffect(()=>{
const p=g=>{
i.current&&j(g.clientX)}
,S=g=>{
i.current&&j(g.touches[0].clientX)}
,q=()=>{
i.current=!1}
;
return window.addEventListener("mousemove",p,{
passive:!0}
),window.addEventListener("mouseup",q),window.addEventListener("touchmove",S,{
passive:!0}
),window.addEventListener("touchend",q),()=>{
window.removeEventListener("mousemove",p),window.removeEventListener("mouseup",q),window.removeEventListener("touchmove",S),window.removeEventListener("touchend",q)}
}
,[c,u]);
const k=p=>{
p!==o&&(r(Math.round(p==="pol"?a/2.54:a*2.54)),n(p))}
,D=(()=>{
const p=[];
for(let S=c;
S<=u;
S++)p.push(S);
return p}
)(),z=D.length*f,W=(a-c)/(u-c)*z;
return e.jsx(v,{
step:16,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-4",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-4 text-center",children:"Qual é a sua altura?"}
),e.jsxs("div",{
className:"flex justify-center gap-2 mb-4",children:[e.jsx("button",{
onClick:()=>k("cm"),className:`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
o==="cm"?"bg-primary text-primary-foreground":"bg-muted text-muted-foreground"}
`,children:"cm"}
),e.jsx("button",{
onClick:()=>k("pol"),className:`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
o==="pol"?"bg-primary text-primary-foreground":"bg-muted text-muted-foreground"}
`,children:"pol"}
)]}
),e.jsxs("div",{
className:"flex items-baseline justify-center mb-4",children:[e.jsx("span",{
className:"text-5xl font-black text-foreground tracking-tight",children:a}
),e.jsx("span",{
className:"text-base text-muted-foreground/60 ml-0.5",children:o==="cm"?"cm":"pol"}
)]}
),e.jsxs("div",{
className:"mb-2",children:[e.jsxs("div",{
ref:l,className:"relative h-24 cursor-grab active:cursor-grabbing select-none overflow-hidden",onMouseDown:w,onTouchStart:y,children:[e.jsxs("div",{
className:"absolute left-1/2 z-10 flex flex-col items-center",style:{
transform:"translateX(-50%)",top:"8px"}
,children:[e.jsx("div",{
className:"w-0.5 bg-primary",style:{
height:"60px"}
}
),e.jsx("div",{
className:"w-0 h-0",style:{
borderLeft:"8px solid transparent",borderRight:"8px solid transparent",borderBottom:"10px solid hsl(var(--primary))"}
}
)]}
),e.jsx("div",{
className:"absolute h-px bg-muted-foreground/50",style:{
top:"8px",left:"50%",transform:`translateX(-${
W}
px)`,width:`${
z}
px`}
}
),e.jsx("div",{
className:"absolute flex items-start",style:{
top:"8px",left:"50%",transform:`translateX(-${
W}
px)`}
,children:D.map(p=>e.jsx("div",{
className:"flex flex-col items-center",style:{
width:`${
f}
px`,flexShrink:0}
,children:e.jsx("div",{
className:"w-px h-4 bg-muted-foreground/50"}
)}
,p))}
),e.jsx("div",{
className:"absolute flex items-start",style:{
top:"28px",left:"50%",transform:`translateX(-${
W}
px)`}
,children:D.filter(p=>p%10===0).map(p=>{
const S=(p-c)*f;
return e.jsx("span",{
className:"absolute text-xs text-muted-foreground/60",style:{
left:`${
S}
px`,transform:"translateX(-50%)"}
,children:p}
,p)}
)}
),e.jsx("div",{
className:"absolute h-px bg-muted-foreground/50",style:{
top:"78px",left:"50%",transform:`translateX(-${
W}
px)`,width:`${
z}
px`}
}
)]}
),e.jsx("p",{
className:"text-center text-xs text-muted-foreground/40 -mt-4",children:"Arraste para ajustar"}
)]}
),e.jsx("div",{
className:"bg-muted/50 rounded-xl p-3 mb-4",children:e.jsxs("div",{
className:"flex items-center gap-2",children:[e.jsx("div",{
className:"w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0",children:e.jsx("span",{
className:"text-xs text-primary font-bold",children:"i"}
)}
),e.jsx("span",{
className:"text-sm font-medium text-foreground",children:"Calculando seu IMC"}
)]}
)}
),e.jsx(O,{
onClick:()=>t(o==="cm"?a:Math.round(a*2.54)),children:"Próximo passo"}
)]}
)}
)}
)}
,Ao=({
onContinue:t,onBack:s,height:a}
)=>{
const[r,o]=h.useState(73),[n,l]=h.useState("kg"),i=h.useRef(null),d=h.useRef(!1),m=h.useRef(0),c=h.useRef(73),u=n==="kg"?30:66,f=n==="kg"?200:440,N=14,j=g=>{
d.current=!0,m.current=g,c.current=r}
,w=g=>{
if(!d.current)return;
const I=(m.current-g)/N,x=Math.max(u,Math.min(f,c.current+I));
o(Math.round(x))}
,y=g=>{
g.preventDefault(),j(g.clientX)}
,k=g=>{
j(g.touches[0].clientX)}
;
h.useEffect(()=>{
const g=x=>{
d.current&&w(x.clientX)}
,B=x=>{
d.current&&w(x.touches[0].clientX)}
,I=()=>{
d.current=!1}
;
return window.addEventListener("mousemove",g,{
passive:!0}
),window.addEventListener("mouseup",I),window.addEventListener("touchmove",B,{
passive:!0}
),window.addEventListener("touchend",I),()=>{
window.removeEventListener("mousemove",g),window.removeEventListener("mouseup",I),window.removeEventListener("touchmove",B),window.removeEventListener("touchend",I)}
}
,[u,f]);
const E=g=>{
g!==n&&(o(Math.round(g==="lb"?r*2.205:r/2.205)),l(g))}
,z=(()=>{
const g=[];
for(let B=u;
B<=f;
B++)g.push(B);
return g}
)(),W=z.length*N,p=(r-u)/(f-u)*W,S=h.useMemo(()=>{
const g=n==="kg"?r:r/2.205,B=a/100;
return(g/(B*B)).toFixed(2)}
,[r,a,n]),q=h.useMemo(()=>{
const g=parseFloat(S);
return g<18.5?{
label:"baixo peso",color:"text-bmi-underweight"}
:g<25?{
label:"normal",color:"text-bmi-normal"}
:g<30?{
label:"sobrepeso",color:"text-bmi-overweight"}
:{
label:"obeso",color:"text-bmi-obese"}
}
,[S]);
return e.jsx(v,{
step:17,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-4",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-4 text-center",children:"Qual é o seu peso agora?"}
),e.jsxs("div",{
className:"flex justify-center gap-2 mb-4",children:[e.jsx("button",{
onClick:()=>E("kg"),className:`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
n==="kg"?"bg-primary text-primary-foreground":"bg-muted text-muted-foreground"}
`,children:"kg"}
),e.jsx("button",{
onClick:()=>E("lb"),className:`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
n==="lb"?"bg-primary text-primary-foreground":"bg-muted text-muted-foreground"}
`,children:"Libra"}
)]}
),e.jsxs("div",{
className:"flex items-baseline justify-center mb-4",children:[e.jsx("span",{
className:"text-5xl font-black text-foreground tracking-tight",children:r}
),e.jsx("span",{
className:"text-base text-muted-foreground/60 ml-0.5",children:n}
)]}
),e.jsxs("div",{
className:"mb-2",children:[e.jsxs("div",{
ref:i,className:"relative h-24 cursor-grab active:cursor-grabbing select-none overflow-hidden",onMouseDown:y,onTouchStart:k,children:[e.jsxs("div",{
className:"absolute left-1/2 z-10 flex flex-col items-center",style:{
transform:"translateX(-50%)",top:"8px"}
,children:[e.jsx("div",{
className:"w-0.5 bg-primary",style:{
height:"60px"}
}
),e.jsx("div",{
className:"w-0 h-0",style:{
borderLeft:"8px solid transparent",borderRight:"8px solid transparent",borderBottom:"10px solid hsl(var(--primary))"}
}
)]}
),e.jsx("div",{
className:"absolute h-px bg-muted-foreground/50",style:{
top:"8px",left:"50%",transform:`translateX(-${
p}
px)`,width:`${
W}
px`}
}
),e.jsx("div",{
className:"absolute flex items-start",style:{
top:"8px",left:"50%",transform:`translateX(-${
p}
px)`}
,children:z.map(g=>e.jsx("div",{
className:"flex flex-col items-center",style:{
width:`${
N}
px`,flexShrink:0}
,children:e.jsx("div",{
className:"w-px h-4 bg-muted-foreground/50"}
)}
,g))}
),e.jsx("div",{
className:"absolute flex items-start",style:{
top:"28px",left:"50%",transform:`translateX(-${
p}
px)`}
,children:z.filter(g=>g%10===0).map(g=>{
const B=(g-u)*N;
return e.jsx("span",{
className:"absolute text-xs text-muted-foreground/60",style:{
left:`${
B}
px`,transform:"translateX(-50%)"}
,children:g}
,g)}
)}
),e.jsx("div",{
className:"absolute h-px bg-muted-foreground/50",style:{
top:"78px",left:"50%",transform:`translateX(-${
p}
px)`,width:`${
W}
px`}
}
)]}
),e.jsx("p",{
className:"text-center text-xs text-muted-foreground/40 -mt-4",children:"Arraste para ajustar"}
)]}
),e.jsxs("div",{
className:"bg-muted rounded-xl p-3 mb-4",children:[e.jsxs("p",{
className:"text-sm text-foreground",children:["Seu IMC é ",e.jsx("span",{
className:"font-bold",children:S}
),", que é considerado"," ",e.jsx("span",{
className:`font-bold ${
q.color}
`,children:q.label}
),"."]}
),e.jsx("p",{
className:"text-xs text-muted-foreground mt-1",children:"Mantenha-se positivo e concentre-se em uma dieta equilibrada e exercícios."}
)]}
),e.jsx(O,{
onClick:()=>t(n==="kg"?r:Math.round(r/2.205)),children:"Próximo passo"}
)]}
)}
)}
)}
,Eo=({
onContinue:t,onBack:s}
)=>{
const[a,r]=h.useState(57),[o,n]=h.useState("kg"),l=h.useRef(null),i=h.useRef(!1),d=h.useRef(0),m=h.useRef(57),c=o==="kg"?30:66,u=o==="kg"?200:440,f=14,N=p=>{
i.current=!0,d.current=p,m.current=a}
,j=p=>{
if(!i.current)return;
const q=(d.current-p)/f,g=Math.max(c,Math.min(u,m.current+q));
r(Math.round(g))}
,w=p=>{
p.preventDefault(),N(p.clientX)}
,y=p=>{
N(p.touches[0].clientX)}
;
h.useEffect(()=>{
const p=g=>{
i.current&&j(g.clientX)}
,S=g=>{
i.current&&j(g.touches[0].clientX)}
,q=()=>{
i.current=!1}
;
return window.addEventListener("mousemove",p,{
passive:!0}
),window.addEventListener("mouseup",q),window.addEventListener("touchmove",S,{
passive:!0}
),window.addEventListener("touchend",q),()=>{
window.removeEventListener("mousemove",p),window.removeEventListener("mouseup",q),window.removeEventListener("touchmove",S),window.removeEventListener("touchend",q)}
}
,[c,u]);
const k=p=>{
p!==o&&(r(Math.round(p==="lb"?a*2.205:a/2.205)),n(p))}
,D=(()=>{
const p=[];
for(let S=c;
S<=u;
S++)p.push(S);
return p}
)(),z=D.length*f,W=(a-c)/(u-c)*z;
return e.jsx(v,{
step:18,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-4",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-4 text-center",children:"Qual é o seu peso alvo?"}
),e.jsxs("div",{
className:"flex justify-center gap-2 mb-4",children:[e.jsx("button",{
onClick:()=>k("kg"),className:`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
o==="kg"?"bg-primary text-primary-foreground":"bg-muted text-muted-foreground"}
`,children:"kg"}
),e.jsx("button",{
onClick:()=>k("lb"),className:`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
o==="lb"?"bg-primary text-primary-foreground":"bg-muted text-muted-foreground"}
`,children:"Libra"}
)]}
),e.jsxs("div",{
className:"flex items-baseline justify-center mb-4",children:[e.jsx("span",{
className:"text-5xl font-black text-foreground tracking-tight",children:a}
),e.jsx("span",{
className:"text-base text-muted-foreground/60 ml-0.5",children:o}
)]}
),e.jsxs("div",{
className:"mb-2",children:[e.jsxs("div",{
ref:l,className:"relative h-24 cursor-grab active:cursor-grabbing select-none overflow-hidden",onMouseDown:w,onTouchStart:y,children:[e.jsxs("div",{
className:"absolute left-1/2 z-10 flex flex-col items-center",style:{
transform:"translateX(-50%)",top:"8px"}
,children:[e.jsx("div",{
className:"w-0.5 bg-primary",style:{
height:"60px"}
}
),e.jsx("div",{
className:"w-0 h-0",style:{
borderLeft:"8px solid transparent",borderRight:"8px solid transparent",borderBottom:"10px solid hsl(var(--primary))"}
}
)]}
),e.jsx("div",{
className:"absolute h-px bg-muted-foreground/50",style:{
top:"8px",left:"50%",transform:`translateX(-${
W}
px)`,width:`${
z}
px`}
}
),e.jsx("div",{
className:"absolute flex items-start",style:{
top:"8px",left:"50%",transform:`translateX(-${
W}
px)`}
,children:D.map(p=>e.jsx("div",{
className:"flex flex-col items-center",style:{
width:`${
f}
px`,flexShrink:0}
,children:e.jsx("div",{
className:"w-px h-4 bg-muted-foreground/50"}
)}
,p))}
),e.jsx("div",{
className:"absolute flex items-start",style:{
top:"28px",left:"50%",transform:`translateX(-${
W}
px)`}
,children:D.filter(p=>p%10===0).map(p=>{
const S=(p-c)*f;
return e.jsx("span",{
className:"absolute text-xs text-muted-foreground/60",style:{
left:`${
S}
px`,transform:"translateX(-50%)"}
,children:p}
,p)}
)}
),e.jsx("div",{
className:"absolute h-px bg-muted-foreground/50",style:{
top:"78px",left:"50%",transform:`translateX(-${
W}
px)`,width:`${
z}
px`}
}
)]}
),e.jsx("p",{
className:"text-center text-xs text-muted-foreground/40 -mt-4",children:"Arraste para ajustar"}
)]}
),e.jsx(O,{
onClick:()=>t(o==="kg"?a:Math.round(a/2.205)),children:"Próximo passo"}
)]}
)}
)}
)}
,zo=({
onContinue:t,onBack:s}
)=>{
const[a,r]=h.useState(""),o=l=>{
const i=l.replace(/\D/g,"");
(i===""||parseInt(i)>=0&&parseInt(i)<=120)&&r(i)}
,n=a!==""&&parseInt(a)>=10&&parseInt(a)<=120;
return e.jsx(v,{
step:19,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-4",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-6 text-center",children:"Qual é a sua idade?"}
),e.jsx("div",{
className:"mb-6",children:e.jsx("input",{
type:"text",inputMode:"numeric",pattern:"[0-9]*",value:a,onChange:l=>o(l.target.value),placeholder:"Digite sua idade",className:"w-full px-4 py-4 text-lg text-foreground bg-background border border-border rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"}
)}
),e.jsxs("div",{
className:"bg-muted/50 rounded-xl p-4 mb-4",children:[e.jsxs("div",{
className:"flex items-start gap-2 mb-2",children:[e.jsx("div",{
className:"w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5",children:e.jsx("span",{
className:"text-xs text-primary font-bold",children:"i"}
)}
),e.jsx("span",{
className:"text-sm font-medium text-foreground",children:"Perguntamos sua idade para personalizar seu plano"}
)]}
),e.jsx("p",{
className:"text-xs text-muted-foreground ml-7",children:"As pessoas mais velhas têm um percentual de gordura corporal mais alto do que as pessoas mais jovens com o mesmo IMC."}
)]}
),e.jsx(O,{
onClick:()=>t(parseInt(a)),disabled:!n,children:"Próximo passo"}
)]}
)}
)}
)}
,Oo=({
onSelect:t,onBack:s}
)=>{
const a=[{
id:"sedentario",label:"Sedentário",description:"Eu passo a maior parte do dia sentado",image:Rt}
,{
id:"moderado",label:"Atividade moderada",description:"Eu faço pausas ativas",image:Lt}
,{
id:"ativo",label:"Eu sou imparável",description:"Estou de pé o dia todo",image:$t}
];
return e.jsx(v,{
step:20,totalSteps:34,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-6 text-center",children:"Como você descreveria seu dia típico?"}
),e.jsx("div",{
className:"space-y-3",children:a.map(r=>e.jsx(P,{
onClick:()=>t(r.id),description:r.description,image:r.image,children:r.label}
,r.id))}
)]}
)}
)}
)}
,Do=({
onContinue:t,onBack:s}
)=>{
const a=[{
id:"baixo",label:"Baixo, sinto-me cansada durante todo o dia"}
,{
id:"queda",label:"Queda pós-almoço"}
,{
id:"arrastando",label:"Arrastando antes das refeições"}
,{
id:"alto",label:"Alto e estável"}
];
return e.jsx(v,{
step:21,totalSteps:34,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-6 overflow-y-auto",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-6 text-center",children:"Como estão seus níveis de energia durante o dia?"}
),e.jsx("div",{
className:"space-y-3",children:a.map(r=>e.jsx(P,{
onClick:()=>t([r.id]),children:r.label}
,r.id))}
)]}
)}
)}
)}
,qo=({
onSelect:t,onBack:s}
)=>{
const a=[{
id:"cafe",label:"Eu só tomo café ou chá"}
,{
id:"2copos",label:"Cerca de 2 copos (0,5 L)"}
,{
id:"2a6copos",label:"2 a 6 copos (0,5–1,5 L)"}
,{
id:"mais6",label:"Mais de 6 copos"}
];
return e.jsx(v,{
step:22,totalSteps:33,showBack:!0,onBack:s,children:e.jsxs("div",{
className:"flex-1 flex flex-col px-4 py-6",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-6 text-center max-w-md mx-auto",children:"Quanto de água você bebe diariamente?"}
),e.jsxs("div",{
className:"relative w-full h-[75vh] md:h-[420px]",children:[e.jsx("div",{
className:"absolute right-1/2 top-0 max-w-xs space-y-3 z-10",children:a.map(r=>e.jsx(P,{
onClick:()=>t(r.id),children:r.label}
,r.id))}
),e.jsx("img",{
src:Ft,alt:"Mulher bebendo água",className:"absolute left-1/2 top-0 h-full md:h-[400px] pointer-events-none -translate-x-[15%] z-0 object-cover object-top"}
)]}
)]}
)}
)}
,To=({
onSelect:t,onBack:s}
)=>{
const a=[{
id:"menos5",label:"Menos de 5 horas"}
,{
id:"5a6",label:"5-6 horas"}
,{
id:"7a8",label:"7-8 horas"}
,{
id:"mais8",label:"Mais de 8 horas"}
];
return e.jsx(v,{
step:23,totalSteps:34,showBack:!0,onBack:s,children:e.jsxs("div",{
className:"flex-1 flex flex-col px-4 py-4 md:py-6",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-1 md:mb-6 text-center max-w-md mx-auto",children:"Quantas horas você costuma dormir?"}
),e.jsxs("div",{
className:"md:hidden flex flex-col items-center",children:[e.jsx("div",{
className:"w-full mb-4",style:{
minHeight:200}
,children:e.jsx(ie,{
src:Xt,alt:"Mulher dormindo",className:"w-full h-auto rounded-lg",priority:!0}
)}
),e.jsx("div",{
className:"grid grid-cols-2 gap-3 w-full max-w-sm",children:a.map(r=>e.jsx(P,{
onClick:()=>t(r.id),children:r.label}
,r.id))}
)]}
),e.jsxs("div",{
className:"hidden md:block relative w-full h-[420px]",children:[e.jsx("div",{
className:"absolute right-1/2 top-0 max-w-xs space-y-3 z-10",children:a.map(r=>e.jsx(P,{
onClick:()=>t(r.id),children:r.label}
,r.id))}
),e.jsx(ie,{
src:Ht,alt:"Mulher dormindo",className:"absolute left-1/2 top-0 h-[400px] pointer-events-none -translate-x-[15%] z-0",style:{
objectFit:"contain",objectPosition:"top"}
,priority:!0}
)]}
)]}
)}
)}
,Ns=[{
id:"vegetarian",label:"Eu sou vegetariana",description:"Verduras, grãos, mas sem carne animal",image:Vt}
,{
id:"vegan",label:"Eu sou vegana",description:"Puramente à base de plantas, sem produtos de origem animal",image:_t}
,{
id:"gluten-free",label:"Não contém glúten",description:"Exclua produtos de grãos que contenham glúten",image:Gt}
,{
id:"lactose-free",label:"Sem lactose",description:"Excluir produtos lácteos",image:Yt}
,{
id:"no-restrictions",label:"Sem restrições",description:"Aberto a todos os alimentos",image:Qt}
],Wo=({
onContinue:t,onBack:s}
)=>{
const[a,r]=h.useState([]),o=n=>{
r(l=>l.includes(n)?l.filter(i=>i!==n):[...l,n])}
;
return e.jsxs(v,{
step:23,totalSteps:35,showBack:!0,onBack:s,children:[e.jsxs("div",{
className:"flex-1 flex flex-col px-4 py-4 md:py-6 pb-32 md:pb-48 overflow-y-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-4 md:mb-6 text-center max-w-md mx-auto",children:"Quais são suas preferências de refeição?"}
),e.jsx("div",{
className:"w-full max-w-md mx-auto space-y-3",children:Ns.map(n=>e.jsx(P,{
onClick:()=>o(n.id),selected:a.includes(n.id),showCheckbox:!0,image:n.image,description:n.description,children:n.label}
,n.id))}
)]}
),e.jsx("div",{
className:"fixed bottom-0 left-0 right-0 p-4 z-10",children:e.jsx("div",{
className:"w-full max-w-md mx-auto",children:e.jsx(O,{
onClick:()=>t(a),disabled:a.length===0,children:"Continuar"}
)}
)}
)]}
)}
,Bo=({
onContinue:t,onBack:s}
)=>{
const[a,r]=h.useState([]),o=l=>{
if(l==="nenhuma"){
r(["nenhuma"]);
return}
r(i=>{
const d=i.filter(m=>m!=="nenhuma");
return d.includes(l)?d.filter(m=>m!==l):[...d,l]}
)}
,n=[{
id:"emocional",label:"Comer emocionalmente ou por tédio"}
,{
id:"demais",label:"Comer demais"}
,{
id:"lanche-noturno",label:"Lanche noturno"}
,{
id:"pular-refeicoes",label:"Pular refeições com muita frequência"}
,{
id:"nenhuma",label:"Nenhuma das opções acima"}
];
return e.jsxs(v,{
step:24,totalSteps:35,showBack:!0,onBack:s,children:[e.jsxs("div",{
className:"flex-1 flex flex-col px-4 py-4 md:py-6 pb-24",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-2 text-center max-w-md mx-auto",children:"Você tem algum desses hábitos?"}
),e.jsx("p",{
className:"text-muted-foreground text-center mb-6",children:"Escolha todas as opções aplicáveis"}
),e.jsx("div",{
className:"grid grid-cols-1 gap-3 w-full max-w-md mx-auto",children:n.map(l=>e.jsx(P,{
onClick:()=>o(l.id),selected:a.includes(l.id),showCheckbox:!0,children:l.label}
,l.id))}
)]}
),e.jsx("div",{
className:"fixed bottom-0 left-0 right-0 p-4 z-10",children:e.jsx("div",{
className:"w-full max-w-md mx-auto",children:e.jsx(O,{
onClick:()=>t(a),disabled:a.length===0,children:"Próximo passo"}
)}
)}
)]}
)}
,Io=({
onContinue:t,onBack:s,userData:a}
)=>{
const r=a.currentWeight/(a.height/100)**2,o=r.toFixed(1),n=()=>(Math.min(Math.max(r,15),40)-15)/25*100,l=()=>({
calmo:"Sedentário",familia:"Moderado",ativo:"Ativo",sedentario:"Sedentário",moderado:"Moderado"}
)[a.lifestyle]||"Sedentário",i=()=>({
"muito-ativo":"Avançado","exercicio-passado":"Intermediário",caminhadas:"Iniciante","sem-exercicio":"Iniciante"}
)[a.fitnessHistory||""]||"Iniciante",d=()=>r<25?"Preguiçoso, tendência à flacidez":r<30?"Em resistência, difícil queimar gordura":"Lento, fácil de ganhar peso",c=r<18.5?{
title:"Alerta de Fragilidade Metabólica:",description:"Embora seu peso seja baixo, seu metabolismo está desequilibrado. A falta de estímulo nas fibras profundas causa perda de tônus e fragilidade interna. O Protocolo Asiático é essencial para fortalecer sua base e garantir um corpo firme, saudável e funcional."}
:r<25?{
title:"Alerta de Estagnação:",description:'Cuidado com o efeito "falsa magra". Seu peso está normal, mas seu metabolismo está estagnado. Sem a ativação das fibras profundas, o corpo acumula gordura visceral e perde a definição. Você precisa destravar sua queima natural agora para evitar a flacidez e o envelhecimento metabólico.'}
:r<30?{
title:"Alerta de Bloqueio:",description:"Seu metabolismo entrou em modo de resistência. O excesso de peso está sobrecarregando suas articulações e travando sua energia diária. O segredo para voltar a secar é a ativação rítmica das fibras profundas, que derrete a gordura mais difícil sem o esforço exaustivo da academia."}
:{
title:"Alerta de Risco Urgente:",description:'Seu metabolismo está em "modo de sobrevivência", travando a queima e gerando inflamação. Isso causa fadiga crônica e riscos sérios à sua saúde. A Calistenia Asiática é a única via segura para destravar seu sistema e eliminar gordura de forma rápida, sem impacto e sem exaustão.'}
;
return e.jsx(v,{
step:30,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-3 py-2 md:px-4 md:py-3",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-lg md:text-xl font-bold text-foreground mb-2.5 md:mb-3 text-center",children:"Seu perfil está pronto"}
),e.jsxs("div",{
className:"bg-card rounded-xl p-3 mb-2 md:mb-2.5 quiz-shadow",children:[e.jsx("p",{
className:"text-sm font-medium text-foreground mb-6",children:"Índice de Massa Corporal (IMC)"}
),e.jsx("div",{
className:"relative mb-2",children:e.jsxs("div",{
className:"absolute -top-5 transform -translate-x-1/2 bg-foreground text-background text-xs px-2 py-0.5 rounded font-semibold whitespace-nowrap",style:{
left:`${
n()}
%`}
,children:["Você - ",o,e.jsx("div",{
className:"absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-foreground"}
)]}
)}
),e.jsxs("div",{
className:"flex justify-between text-xs text-muted-foreground mb-1 px-0.5",children:[e.jsx("span",{
children:"15"}
),e.jsx("span",{
children:"18,5"}
),e.jsx("span",{
children:"25"}
),e.jsx("span",{
children:"30"}
),e.jsx("span",{
children:"40"}
)]}
),e.jsxs("div",{
className:"relative h-3 rounded-full overflow-hidden mb-1",children:[e.jsx("div",{
className:"absolute inset-0",style:{
background:"linear-gradient(to right, #60a5fa 0%, #22c55e 30%, #facc15 50%, #f97316 70%, #ef4444 100%)"}
}
),e.jsx("div",{
className:"absolute top-0 w-3 h-3 bg-white rounded-full border-2 border-foreground shadow-md transform -translate-x-1/2",style:{
left:`${
n()}
%`}
}
)]}
),e.jsxs("div",{
className:"flex justify-between text-[10px] text-muted-foreground mt-0.5",children:[e.jsx("span",{
className:r<18.5?"font-bold text-foreground":"",children:"ABAIXO DO PESO"}
),e.jsx("span",{
className:r>=18.5&&r<25?"font-bold text-foreground":"",children:"NORMAL"}
),e.jsx("span",{
className:r>=25&&r<30?"font-bold text-foreground":"",children:"SOBREPESO"}
),e.jsx("span",{
className:r>=30?"font-bold text-foreground":"",children:"OBESO"}
)]}
)]}
),e.jsx("div",{
className:"bg-red-50 border border-red-200 rounded-xl p-2.5 md:p-3 mb-2 md:mb-2.5",children:e.jsxs("div",{
className:"flex items-start gap-2",children:[e.jsx(ds,{
className:"w-4 h-4 text-red-500 flex-shrink-0 mt-0.5"}
),e.jsxs("div",{
children:[e.jsx("p",{
className:"text-sm font-bold text-red-700 mb-0.5",children:c.title}
),e.jsx("p",{
className:"text-xs text-red-600 leading-relaxed",children:c.description}
)]}
)]}
)}
),e.jsx("div",{
className:"bg-card rounded-xl p-2.5 md:p-3 mb-2 md:mb-2.5 quiz-shadow",children:e.jsxs("div",{
className:"space-y-2 md:space-y-2.5",children:[e.jsxs("div",{
className:"flex items-center gap-2.5 pb-2 border-b border-border",children:[e.jsx(Ga,{
className:"w-4 h-4 text-muted-foreground"}
),e.jsxs("div",{
children:[e.jsx("p",{
className:"text-xs text-muted-foreground",children:"Estilo de vida"}
),e.jsx("p",{
className:"text-sm font-semibold text-foreground",children:l()}
)]}
)]}
),e.jsxs("div",{
className:"flex items-center gap-2.5 pb-2 border-b border-border",children:[e.jsx(ms,{
className:"w-4 h-4 text-muted-foreground"}
),e.jsxs("div",{
children:[e.jsx("p",{
className:"text-xs text-muted-foreground",children:"Nível de condicionamento"}
),e.jsx("p",{
className:"text-sm font-semibold text-foreground",children:i()}
)]}
)]}
),e.jsxs("div",{
className:"flex items-center gap-2.5",children:[e.jsx(ce,{
className:"w-4 h-4 text-muted-foreground"}
),e.jsxs("div",{
children:[e.jsx("p",{
className:"text-xs text-muted-foreground",children:"Metabolismo"}
),e.jsx("p",{
className:"text-sm font-semibold text-foreground",children:d()}
)]}
)]}
)]}
)}
),e.jsx(O,{
onClick:t,children:"Continuar"}
)]}
)}
)}
)}
,Ro=({
onContinue:t,onBack:s}
)=>{
const[a,r]=h.useState([]),o=i=>{
r(d=>d.includes(i)?d.filter(m=>m!==i):[...d,i])}
,n=[{
id:"yoga",label:"Ioga",description:"Reduza o estresse e traga equilíbrio à sua vida"}
,{
id:"barra",label:"Barra",description:"Afine seus músculos, mesmo os ocultos"}
,{
id:"resistencia",label:"Resistência",description:"Trabalhe esses músculos para ficar mais forte"}
,{
id:"caminhada",label:"Caminhada",description:"Energize seu corpo, fortaleça cada passo"}
],l=e.jsx(O,{
onClick:()=>t(a),disabled:a.length===0,children:"Continuar"}
);
return e.jsx(v,{
step:25,totalSteps:35,showBack:!0,onBack:s,stickyFooter:l,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-1 text-center",children:"O que você acrescentaria além da Calistenia?"}
),e.jsx("p",{
className:"text-muted-foreground mb-6 text-center",children:"Selecione pelo menos um"}
),e.jsx("div",{
className:"space-y-3",children:n.map(i=>e.jsx(P,{
onClick:()=>o(i.id),selected:a.includes(i.id),showCheckbox:!0,description:i.description,children:i.label}
,i.id))}
)]}
)}
)}
)}
,ks="/assets/women-group-MPSXHGjC.jpg",Lo=({
onContinue:t,onBack:s,selectedActivities:a}
)=>{
const r={
yoga:"Ioga",barra:"Barra",resistencia:"Resistência",caminhada:"Caminhada"}
,o=a.map(n=>r[n]||n);
return e.jsx(v,{
step:26,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto text-center",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-4",children:"Já estamos preparando seu plano personalizado"}
),e.jsxs("p",{
className:"text-muted-foreground mb-6 text-sm leading-relaxed",children:["Adicionamos as atividades que você selecionou ao seu plano:"," ",e.jsx("span",{
className:"text-primary font-semibold",children:o.join(", ")}
),". Eles a ajudarão gentilmente a se sentir mais forte, com mais mobilidade e mais em sintonia consigo mesma - em todos os estágios da menopausa."]}
),e.jsx("div",{
className:"mb-6 rounded-2xl overflow-hidden quiz-shadow-lg",children:e.jsx("img",{
src:ks,alt:"Mulheres praticando atividades",className:"w-full h-64 object-cover"}
)}
),e.jsx(O,{
onClick:t,children:"Continuar"}
)]}
)}
)}
)}
,Ss="/assets/woman-water-BNw0WgAm.jpg",$o=({
onSelect:t,onBack:s}
)=>{
const a=[{
id:"cafe-cha",label:"Eu só tomo café ou chá"}
,{
id:"2-copos",label:"Cerca de 2 copos (0,5 L)"}
,{
id:"2-6-copos",label:"2 a 6 copos (0,5-1,5 L)"}
,{
id:"mais-6-copos",label:"Mais de 6 copos"}
];
return e.jsx(v,{
step:27,totalSteps:35,showBack:!0,onBack:s,children:e.jsxs("div",{
className:"flex-1 flex flex-col lg:flex-row",children:[e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-6 text-center",children:"Quanta água você bebe diariamente?"}
),e.jsx("div",{
className:"space-y-3",children:a.map(r=>e.jsx(P,{
onClick:()=>t(r.id),children:r.label}
,r.id))}
)]}
)}
),e.jsx("div",{
className:"hidden lg:block lg:w-1/2 bg-muted",children:e.jsx("img",{
src:Ss,alt:"Mulher bebendo água",className:"w-full h-full object-cover"}
)}
)]}
)}
)}
,Fo=({
onSelect:t,onBack:s}
)=>{
const a=[{
id:"sem-restricao",label:"Sem restrições",description:"Aberto a todos os alimentos"}
,{
id:"vegetariano",label:"Eu sou vegetariano",description:"Verduras, cereais, mas sem carne animal"}
,{
id:"vegano",label:"Eu sou vegano",description:"Puramente à base de plantas, sem produtos de origem animal"}
,{
id:"sem-gluten",label:"Sem glúten",description:"Exclua produtos de cereais que contenham glúten"}
,{
id:"sem-lactose",label:"Sem lactose",description:"Excluir laticínios"}
,{
id:"cetogenica",label:"Dieta cetogênica",description:"Dieta com baixo teor de carboidratos e alto teor de gordura"}
];
return e.jsx(v,{
step:28,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-6 overflow-y-auto",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-6 text-center",children:"Quais são suas preferências alimentares?"}
),e.jsx("div",{
className:"space-y-3 pb-4",children:a.map(r=>e.jsx(P,{
onClick:()=>t(r.id),description:r.description,children:r.label}
,r.id))}
)]}
)}
)}
)}
,Xo=({
onContinue:t,onBack:s}
)=>{
const[a,r]=h.useState([]),o=i=>{
if(i==="nenhum"){
r(["nenhum"]);
return}
r(d=>{
const m=d.filter(c=>c!=="nenhum");
return m.includes(i)?m.filter(c=>c!==i):[...m,i]}
)}
,n=[{
id:"procrastinacao",label:"Procrastinação",emoji:"⏰"}
,{
id:"alimentacao",label:"Alimentação pouco saudável",emoji:"🍔"}
,{
id:"redes-sociais",label:"Mídias sociais",emoji:"📱"}
,{
id:"cafe",label:"Beber muita cafeína",emoji:"☕"}
,{
id:"assistir",label:"Maratona de séries",emoji:"📺"}
,{
id:"inseguranca",label:"Dúvida sobre si mesmo",emoji:"💭"}
,{
id:"roer-unhas",label:"Roer as unhas",emoji:"🤚"}
,{
id:"atrasada",label:"Estar atrasada",emoji:"⏳"}
,{
id:"fumar",label:"Fumar",emoji:"🚬"}
,{
id:"alcool",label:"Beber álcool",emoji:"🍷"}
,{
id:"nenhum",label:"Nenhum deles",emoji:"✨"}
],l=e.jsx(O,{
onClick:()=>t(a),disabled:a.length===0,children:"Continuar"}
);
return e.jsx(v,{
step:29,totalSteps:35,showBack:!0,onBack:s,stickyFooter:l,children:e.jsx("div",{
className:"flex-1 px-4 py-6 overflow-y-auto",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-6 text-center",children:"Quais desses hábitos você tem?"}
),e.jsx("div",{
className:"space-y-3",children:n.map(i=>e.jsx(P,{
onClick:()=>o(i.id),selected:a.includes(i.id),showCheckbox:!0,emoji:i.emoji,children:i.label}
,i.id))}
)]}
)}
)}
)}
,Ho=({
onContinue:t,onBack:s}
)=>{
const[a,r]=h.useState([]),o=i=>{
if(i==="nenhuma"){
r(["nenhuma"]);
return}
r(d=>{
const m=d.filter(c=>c!=="nenhuma");
return m.includes(i)?m.filter(c=>c!==i):[...m,i]}
)}
,n=[{
id:"casamento",label:"Casamento ou relacionamento",icon:e.jsx(Ue,{
className:"w-5 h-5"}
)}
,{
id:"gravidez",label:"Gravidez",icon:e.jsx(Ye,{
className:"w-5 h-5"}
)}
,{
id:"trabalho",label:"Trabalho agitado ou vida familiar",icon:e.jsx(Ua,{
className:"w-5 h-5"}
)}
,{
id:"estresse",label:"Estresse ou saúde mental",icon:e.jsx(Ge,{
className:"w-5 h-5"}
)}
,{
id:"medicamento",label:"Medicamento ou distúrbio hormonal",icon:e.jsx(rs,{
className:"w-5 h-5"}
)}
,{
id:"nenhuma",label:"Nenhuma das acima",icon:e.jsx(xs,{
className:"w-5 h-5"}
)}
],l=e.jsx(O,{
onClick:()=>t(a),disabled:a.length===0,children:"Próximo passo"}
);
return e.jsx(v,{
step:30,totalSteps:35,showBack:!0,onBack:s,stickyFooter:l,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-6 text-center",children:"Algum dos eventos abaixo te levou a ganhar peso nos últimos anos?"}
),e.jsx("div",{
className:"space-y-3",children:n.map(i=>e.jsx(P,{
onClick:()=>o(i.id),selected:a.includes(i.id),showCheckbox:!0,icon:i.icon,children:i.label}
,i.id))}
)]}
)}
)}
)}
,Vo=({
onContinue:t,onBack:s}
)=>e.jsx(v,{
step:31,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto text-center",children:[e.jsx("div",{
className:"mb-6 rounded-2xl overflow-hidden quiz-shadow-lg bg-muted",children:e.jsx("img",{
src:Ut,alt:"Mulher motivada",className:"w-full object-contain",loading:"eager",decoding:"async",fetchPriority:"high"}
)}
),e.jsx("h1",{
className:"text-2xl md:text-3xl font-bold text-foreground mb-4",children:"Recupere Seu Corpo!"}
),e.jsx("p",{
className:"text-muted-foreground mb-6 text-sm leading-relaxed",children:"Não sabe por onde começar? Nós já planejamos tudo. Não tem certeza de que pode fazer isso? Estamos prontos para motivá-la e apoiá-la!"}
),e.jsx(O,{
onClick:t,children:"Continuar"}
)]}
)}
)}
),_o=({
onContinue:t,onBack:s}
)=>{
const[a,r]=h.useState(!1);
h.useEffect(()=>{
const n=setTimeout(()=>r(!0),200);
return()=>clearTimeout(n)}
,[]);
const o=320;
return e.jsx(v,{
step:32,totalSteps:36,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsxs("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-2 text-center",children:["É assim que a ",e.jsx("span",{
className:"text-primary",children:"transformação da sua vida"}
)," se parece"]}
),e.jsx("p",{
className:"text-muted-foreground text-center mb-8 text-sm leading-relaxed font-medium",children:"Com base nas suas respostas, prevemos que você está entre as mulheres com mais chances de atingir seus objetivos!"}
),e.jsxs("div",{
className:"relative mb-6",children:[e.jsxs("svg",{
viewBox:"0 0 400 200",className:"w-full h-auto",children:[e.jsx("polygon",{
points:"50,120 350,180 350,200 50,200",fill:"hsl(var(--destructive) / 0.2)",style:{
opacity:a?1:0,transition:"opacity 0.3s ease-out 0.3s"}
}
),e.jsx("polygon",{
points:"50,120 350,60 350,180 50,120",fill:"hsl(142 76% 36% / 0.15)",style:{
opacity:a?1:0,transition:"opacity 0.3s ease-out 0.3s"}
}
),e.jsx("line",{
x1:"50",y1:"120",x2:"350",y2:"60",stroke:"hsl(142 76% 36%)",strokeWidth:"3",strokeDasharray:o,strokeDashoffset:a?0:o,style:{
transition:"stroke-dashoffset 0.4s ease-out"}
}
),e.jsx("line",{
x1:"50",y1:"120",x2:"350",y2:"180",stroke:"hsl(var(--destructive))",strokeWidth:"3",strokeDasharray:o,strokeDashoffset:a?0:o,style:{
transition:"stroke-dashoffset 0.4s ease-out"}
}
),e.jsx("circle",{
cx:"50",cy:"120",r:"8",fill:"hsl(var(--destructive))",style:{
opacity:a?1:0,transform:a?"scale(1)":"scale(0)",transformOrigin:"50px 120px",transition:"opacity 0.2s ease-out, transform 0.2s ease-out"}
}
),e.jsx("circle",{
cx:"350",cy:"60",r:"8",fill:"hsl(142 76% 36%)",style:{
opacity:a?1:0,transform:a?"scale(1)":"scale(0)",transformOrigin:"350px 60px",transition:"opacity 0.15s ease-out 0.35s, transform 0.15s ease-out 0.35s"}
}
),e.jsx("circle",{
cx:"350",cy:"180",r:"8",fill:"hsl(var(--destructive))",style:{
opacity:a?1:0,transform:a?"scale(1)":"scale(0)",transformOrigin:"350px 180px",transition:"opacity 0.15s ease-out 0.35s, transform 0.15s ease-out 0.35s"}
}
),e.jsx("line",{
x1:"50",y1:"60",x2:"50",y2:"120",stroke:"hsl(var(--muted-foreground))",strokeWidth:"1",strokeDasharray:"4,4",style:{
opacity:a?1:0,transition:"opacity 0.3s ease-out"}
}
)]}
),e.jsx("div",{
className:"absolute bg-white border border-border rounded-lg px-3 py-1.5 text-sm font-medium shadow-sm",style:{
left:"5%",top:"45%",opacity:a?1:0,transform:a?"translateX(0)":"translateX(-10px)",transition:"opacity 0.2s ease-out, transform 0.2s ease-out"}
,children:"Você"}
),e.jsx("div",{
className:"absolute bg-green-500 text-white rounded-lg px-3 py-1.5 text-sm font-medium shadow-sm",style:{
right:"0%",top:"15%",opacity:a?1:0,transform:a?"translateX(0)":"translateX(10px)",transition:"opacity 0.15s ease-out 0.4s, transform 0.15s ease-out 0.4s"}
,children:"Com Calistenia Asiática"}
),e.jsx("div",{
className:"absolute bg-red-500 text-white rounded-lg px-3 py-1.5 text-sm font-medium shadow-sm",style:{
right:"0%",bottom:"15%",opacity:a?1:0,transform:a?"translateX(0)":"translateX(10px)",transition:"opacity 0.15s ease-out 0.4s, transform 0.15s ease-out 0.4s"}
,children:"Sem mudanças"}
)]}
),e.jsx(O,{
onClick:t,children:"Continuar"}
)]}
)}
)}
)}
,Go=({
onContinue:t,onBack:s,currentWeight:a,targetWeight:r}
)=>{
const[o,n]=h.useState(!1);
h.useEffect(()=>{
const i=setTimeout(()=>n(!0),200);
return()=>clearTimeout(i)}
,[]);
const l=400;
return e.jsx(v,{
step:32,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 flex flex-col px-4 py-4 md:py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto flex flex-col gap-4 md:gap-5",children:[e.jsx("h1",{
className:"text-lg md:text-2xl font-bold text-foreground text-center",children:"O último plano que você precisará para ficar em forma"}
),e.jsxs("div",{
className:"text-center",children:[e.jsx("p",{
className:"text-muted-foreground text-sm md:text-base mb-2",children:"Prevemos que você estará com"}
),e.jsxs("p",{
children:[e.jsxs("span",{
className:"bg-blue-100 text-blue-600 font-bold px-2 py-1 rounded text-base md:text-lg",children:[r,"kg"]}
),e.jsx("span",{
className:"text-foreground font-bold text-base md:text-lg ml-2",children:"em até 21 dias"}
)]}
)]}
),e.jsx("div",{
className:"relative h-[150px] md:h-[200px]",children:e.jsxs("svg",{
className:"w-full h-full",viewBox:"0 0 400 220",preserveAspectRatio:"xMidYMid meet",children:[e.jsxs("defs",{
children:[e.jsxs("linearGradient",{
id:"areaGradient",x1:"0%",y1:"0%",x2:"100%",y2:"100%",children:[e.jsx("stop",{
offset:"0%",stopColor:"#ef4444",stopOpacity:"0.8"}
),e.jsx("stop",{
offset:"50%",stopColor:"#fbbf24",stopOpacity:"0.7"}
),e.jsx("stop",{
offset:"100%",stopColor:"#22c55e",stopOpacity:"0.6"}
)]}
),e.jsxs("linearGradient",{
id:"lineGradient",x1:"0%",y1:"0%",x2:"100%",y2:"0%",children:[e.jsx("stop",{
offset:"0%",stopColor:"#dc2626"}
),e.jsx("stop",{
offset:"50%",stopColor:"#f59e0b"}
),e.jsx("stop",{
offset:"100%",stopColor:"#16a34a"}
)]}
)]}
),e.jsx("line",{
x1:"30",y1:"200",x2:"380",y2:"200",stroke:"#e5e7eb",strokeWidth:"1",strokeDasharray:"4,4"}
),e.jsx("line",{
x1:"200",y1:"30",x2:"200",y2:"200",stroke:"#e5e7eb",strokeWidth:"1",strokeDasharray:"4,4"}
),e.jsx("path",{
d:"M30,40 Q120,80 200,130 Q280,170 380,190 L380,200 L30,200 Z",fill:"url(#areaGradient)",style:{
opacity:o?1:0,transition:"opacity 0.5s ease-out 0.3s"}
}
),e.jsx("path",{
d:"M30,40 Q120,80 200,130 Q280,170 380,190",fill:"none",stroke:"url(#lineGradient)",strokeWidth:"4",strokeLinecap:"round",strokeDasharray:l,strokeDashoffset:o?0:l,style:{
transition:"stroke-dashoffset 0.6s ease-out"}
}
),e.jsx("circle",{
cx:"30",cy:"40",r:"10",fill:"#dc2626",stroke:"white",strokeWidth:"3",style:{
opacity:o?1:0,transform:o?"scale(1)":"scale(0)",transformOrigin:"30px 40px",transition:"opacity 0.2s ease-out, transform 0.2s ease-out"}
}
),e.jsx("circle",{
cx:"200",cy:"130",r:"8",fill:"#f59e0b",stroke:"white",strokeWidth:"2",style:{
opacity:o?1:0,transform:o?"scale(1)":"scale(0)",transformOrigin:"200px 130px",transition:"opacity 0.2s ease-out 0.3s, transform 0.2s ease-out 0.3s"}
}
),e.jsx("circle",{
cx:"380",cy:"190",r:"10",fill:"#16a34a",stroke:"white",strokeWidth:"3",style:{
opacity:o?1:0,transform:o?"scale(1)":"scale(0)",transformOrigin:"380px 190px",transition:"opacity 0.2s ease-out 0.5s, transform 0.2s ease-out 0.5s"}
}
),e.jsxs("g",{
style:{
opacity:o?1:0,transition:"opacity 0.2s ease-out 0.1s"}
,children:[e.jsx("rect",{
x:"40",y:"20",width:"55",height:"26",rx:"5",fill:"#dc2626"}
),e.jsxs("text",{
x:"67",y:"39",textAnchor:"middle",fill:"white",fontSize:"13",fontWeight:"bold",children:[a,"kg"]}
)]}
),e.jsxs("g",{
style:{
opacity:o?1:0,transition:"opacity 0.2s ease-out 0.35s"}
,children:[e.jsx("rect",{
x:"155",y:"95",width:"75",height:"24",rx:"5",fill:"white",stroke:"#e5e7eb"}
),e.jsx("text",{
x:"192",y:"112",textAnchor:"middle",fill:"#374151",fontSize:"11",children:"Semana 2"}
)]}
),e.jsxs("g",{
style:{
opacity:o?1:0,transition:"opacity 0.2s ease-out 0.55s"}
,children:[e.jsx("rect",{
x:"330",y:"155",width:"55",height:"26",rx:"5",fill:"#16a34a"}
),e.jsxs("text",{
x:"357",y:"174",textAnchor:"middle",fill:"white",fontSize:"13",fontWeight:"bold",children:[r,"kg"]}
)]}
)]}
)}
),e.jsxs("div",{
className:"text-center",children:[e.jsx("h2",{
className:"text-base md:text-lg font-bold text-primary mb-1",children:"Protocolo de 21 dias quase pronto!"}
),e.jsx("p",{
className:"text-muted-foreground text-sm",children:"De acordo com as suas respostas, você está pronta para ter resultados em 21 dias com o nosso programa."}
)]}
),e.jsx(O,{
onClick:t,children:"Continuar"}
)]}
)}
)}
)}
,Yo=({
onSelect:t,onBack:s}
)=>{
const a=[{
id:"confiante",label:"Me sentir mais confiante com o meu corpo.",icon:be}
,{
id:"energia",label:"Ficar mais saudável e ter mais energia.",icon:Ze}
,{
id:"roupas",label:"Me sentir bem nas minhas roupas.",icon:is}
,{
id:"pos-parto",label:"Recuperar o corpo e a autoestima após o parto.",icon:Ya}
,{
id:"outro",label:"Outro.",icon:ts}
];
return e.jsx(v,{
step:31,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-6 text-center",children:"Qual é o seu principal motivo para transformar o seu corpo?"}
),e.jsx("div",{
className:"space-y-3",children:a.map(r=>{
const o=r.icon;
return e.jsx(P,{
onClick:()=>t(r.id),icon:e.jsx(o,{
className:"w-5 h-5"}
),showArrow:!0,children:r.label}
,r.id)}
)}
)]}
)}
)}
)}
;
function R(t){
const s=Object.prototype.toString.call(t);
return t instanceof Date||typeof t=="object"&&s==="[object Date]"?new t.constructor(+t):typeof t=="number"||s==="[object Number]"||typeof t=="string"||s==="[object String]"?new Date(t):new Date(NaN)}
function Q(t,s){
return t instanceof Date?new t.constructor(s):new Date(s)}
function ye(t,s){
const a=R(t);
return isNaN(s)?Q(t,NaN):(a.setDate(a.getDate()+s),a)}
const ot=6048e5,Ms=864e5;
let Cs={
}
;
function xe(){
return Cs}
function le(t,s){
const a=xe(),r=s?.weekStartsOn??s?.locale?.options?.weekStartsOn??a.weekStartsOn??a.locale?.options?.weekStartsOn??0,o=R(t),n=o.getDay(),l=(n<r?7:0)+n-r;
return o.setDate(o.getDate()-l),o.setHours(0,0,0,0),o}
function me(t){
return le(t,{
weekStartsOn:1}
)}
function nt(t){
const s=R(t),a=s.getFullYear(),r=Q(t,0);
r.setFullYear(a+1,0,4),r.setHours(0,0,0,0);
const o=me(r),n=Q(t,0);
n.setFullYear(a,0,4),n.setHours(0,0,0,0);
const l=me(n);
return s.getTime()>=o.getTime()?a+1:s.getTime()>=l.getTime()?a:a-1}
function Ee(t){
const s=R(t);
return s.setHours(0,0,0,0),s}
function ze(t){
const s=R(t),a=new Date(Date.UTC(s.getFullYear(),s.getMonth(),s.getDate(),s.getHours(),s.getMinutes(),s.getSeconds(),s.getMilliseconds()));
return a.setUTCFullYear(s.getFullYear()),+t-+a}
function Ps(t,s){
const a=Ee(t),r=Ee(s),o=+a-ze(a),n=+r-ze(r);
return Math.round((o-n)/Ms)}
function As(t){
const s=nt(t),a=Q(t,0);
return a.setFullYear(s,0,4),a.setHours(0,0,0,0),me(a)}
function Es(t){
return t instanceof Date||typeof t=="object"&&Object.prototype.toString.call(t)==="[object Date]"}
function zs(t){
if(!Es(t)&&typeof t!="number")return!1;
const s=R(t);
return!isNaN(Number(s))}
function Os(t){
const s=R(t),a=Q(t,0);
return a.setFullYear(s.getFullYear(),0,1),a.setHours(0,0,0,0),a}
const Ds={
lessThanXSeconds:{
one:"less than a second",other:"less than {
{
count}
}
 seconds"}
,xSeconds:{
one:"1 second",other:"{
{
count}
}
 seconds"}
,halfAMinute:"half a minute",lessThanXMinutes:{
one:"less than a minute",other:"less than {
{
count}
}
 minutes"}
,xMinutes:{
one:"1 minute",other:"{
{
count}
}
 minutes"}
,aboutXHours:{
one:"about 1 hour",other:"about {
{
count}
}
 hours"}
,xHours:{
one:"1 hour",other:"{
{
count}
}
 hours"}
,xDays:{
one:"1 day",other:"{
{
count}
}
 days"}
,aboutXWeeks:{
one:"about 1 week",other:"about {
{
count}
}
 weeks"}
,xWeeks:{
one:"1 week",other:"{
{
count}
}
 weeks"}
,aboutXMonths:{
one:"about 1 month",other:"about {
{
count}
}
 months"}
,xMonths:{
one:"1 month",other:"{
{
count}
}
 months"}
,aboutXYears:{
one:"about 1 year",other:"about {
{
count}
}
 years"}
,xYears:{
one:"1 year",other:"{
{
count}
}
 years"}
,overXYears:{
one:"over 1 year",other:"over {
{
count}
}
 years"}
,almostXYears:{
one:"almost 1 year",other:"almost {
{
count}
}
 years"}
}
,qs=(t,s,a)=>{
let r;
const o=Ds[t];
return typeof o=="string"?r=o:s===1?r=o.one:r=o.other.replace("{
{
count}
}
",s.toString()),a?.addSuffix?a.comparison&&a.comparison>0?"in "+r:r+" ago":r}
;
function ee(t){
return(s={
}
)=>{
const a=s.width?String(s.width):t.defaultWidth;
return t.formats[a]||t.formats[t.defaultWidth]}
}
const Ts={
full:"EEEE, MMMM do, y",long:"MMMM do, y",medium:"MMM d, y",short:"MM/dd/yyyy"}
,Ws={
full:"h:mm:ss a zzzz",long:"h:mm:ss a z",medium:"h:mm:ss a",short:"h:mm a"}
,Bs={
full:"{
{
date}
}
 'at' {
{
time}
}
",long:"{
{
date}
}
 'at' {
{
time}
}
",medium:"{
{
date}
}
, {
{
time}
}
",short:"{
{
date}
}
, {
{
time}
}
"}
,Is={
date:ee({
formats:Ts,defaultWidth:"full"}
),time:ee({
formats:Ws,defaultWidth:"full"}
),dateTime:ee({
formats:Bs,defaultWidth:"full"}
)}
,Rs={
lastWeek:"'last' eeee 'at' p",yesterday:"'yesterday at' p",today:"'today at' p",tomorrow:"'tomorrow at' p",nextWeek:"eeee 'at' p",other:"P"}
,Ls=(t,s,a,r)=>Rs[t];
function $(t){
return(s,a)=>{
const r=a?.context?String(a.context):"standalone";
let o;
if(r==="formatting"&&t.formattingValues){
const l=t.defaultFormattingWidth||t.defaultWidth,i=a?.width?String(a.width):l;
o=t.formattingValues[i]||t.formattingValues[l]}
else{
const l=t.defaultWidth,i=a?.width?String(a.width):t.defaultWidth;
o=t.values[i]||t.values[l]}
const n=t.argumentCallback?t.argumentCallback(s):s;
return o[n]}
}
const $s={
narrow:["B","A"],abbreviated:["BC","AD"],wide:["Before Christ","Anno Domini"]}
,Fs={
narrow:["1","2","3","4"],abbreviated:["Q1","Q2","Q3","Q4"],wide:["1st quarter","2nd quarter","3rd quarter","4th quarter"]}
,Xs={
narrow:["J","F","M","A","M","J","J","A","S","O","N","D"],abbreviated:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],wide:["January","February","March","April","May","June","July","August","September","October","November","December"]}
,Hs={
narrow:["S","M","T","W","T","F","S"],short:["Su","Mo","Tu","We","Th","Fr","Sa"],abbreviated:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],wide:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]}
,Vs={
narrow:{
am:"a",pm:"p",midnight:"mi",noon:"n",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"}
,abbreviated:{
am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"}
,wide:{
am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"}
}
,_s={
narrow:{
am:"a",pm:"p",midnight:"mi",noon:"n",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"}
,abbreviated:{
am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"}
,wide:{
am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"}
}
,Gs=(t,s)=>{
const a=Number(t),r=a%100;
if(r>20||r<10)switch(r%10){
case 1:return a+"st";
case 2:return a+"nd";
case 3:return a+"rd"}
return a+"th"}
,Ys={
ordinalNumber:Gs,era:$({
values:$s,defaultWidth:"wide"}
),quarter:$({
values:Fs,defaultWidth:"wide",argumentCallback:t=>t-1}
),month:$({
values:Xs,defaultWidth:"wide"}
),day:$({
values:Hs,defaultWidth:"wide"}
),dayPeriod:$({
values:Vs,defaultWidth:"wide",formattingValues:_s,defaultFormattingWidth:"wide"}
)}
;
function F(t){
return(s,a={
}
)=>{
const r=a.width,o=r&&t.matchPatterns[r]||t.matchPatterns[t.defaultMatchWidth],n=s.match(o);
if(!n)return null;
const l=n[0],i=r&&t.parsePatterns[r]||t.parsePatterns[t.defaultParseWidth],d=Array.isArray(i)?Us(i,u=>u.test(l)):Qs(i,u=>u.test(l));
let m;
m=t.valueCallback?t.valueCallback(d):d,m=a.valueCallback?a.valueCallback(m):m;
const c=s.slice(l.length);
return{
value:m,rest:c}
}
}
function Qs(t,s){
for(const a in t)if(Object.prototype.hasOwnProperty.call(t,a)&&s(t[a]))return a}
function Us(t,s){
for(let a=0;
a<t.length;
a++)if(s(t[a]))return a}
function it(t){
return(s,a={
}
)=>{
const r=s.match(t.matchPattern);
if(!r)return null;
const o=r[0],n=s.match(t.parsePattern);
if(!n)return null;
let l=t.valueCallback?t.valueCallback(n[0]):n[0];
l=a.valueCallback?a.valueCallback(l):l;
const i=s.slice(o.length);
return{
value:l,rest:i}
}
}
const Zs=/^(\d+)(th|st|nd|rd)?/i,Js=/\d+/i,Ks={
narrow:/^(b|a)/i,abbreviated:/^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,wide:/^(before christ|before common era|anno domini|common era)/i}
,er={
any:[/^b/i,/^(a|c)/i]}
,tr={
narrow:/^[1234]/i,abbreviated:/^q[1234]/i,wide:/^[1234](th|st|nd|rd)? quarter/i}
,ar={
any:[/1/i,/2/i,/3/i,/4/i]}
,sr={
narrow:/^[jfmasond]/i,abbreviated:/^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,wide:/^(january|february|march|april|may|june|july|august|september|october|november|december)/i}
,rr={
narrow:[/^j/i,/^f/i,/^m/i,/^a/i,/^m/i,/^j/i,/^j/i,/^a/i,/^s/i,/^o/i,/^n/i,/^d/i],any:[/^ja/i,/^f/i,/^mar/i,/^ap/i,/^may/i,/^jun/i,/^jul/i,/^au/i,/^s/i,/^o/i,/^n/i,/^d/i]}
,or={
narrow:/^[smtwf]/i,short:/^(su|mo|tu|we|th|fr|sa)/i,abbreviated:/^(sun|mon|tue|wed|thu|fri|sat)/i,wide:/^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i}
,nr={
narrow:[/^s/i,/^m/i,/^t/i,/^w/i,/^t/i,/^f/i,/^s/i],any:[/^su/i,/^m/i,/^tu/i,/^w/i,/^th/i,/^f/i,/^sa/i]}
,ir={
narrow:/^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,any:/^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i}
,lr={
any:{
am:/^a/i,pm:/^p/i,midnight:/^mi/i,noon:/^no/i,morning:/morning/i,afternoon:/afternoon/i,evening:/evening/i,night:/night/i}
}
,dr={
ordinalNumber:it({
matchPattern:Zs,parsePattern:Js,valueCallback:t=>parseInt(t,10)}
),era:F({
matchPatterns:Ks,defaultMatchWidth:"wide",parsePatterns:er,defaultParseWidth:"any"}
),quarter:F({
matchPatterns:tr,defaultMatchWidth:"wide",parsePatterns:ar,defaultParseWidth:"any",valueCallback:t=>t+1}
),month:F({
matchPatterns:sr,defaultMatchWidth:"wide",parsePatterns:rr,defaultParseWidth:"any"}
),day:F({
matchPatterns:or,defaultMatchWidth:"wide",parsePatterns:nr,defaultParseWidth:"any"}
),dayPeriod:F({
matchPatterns:ir,defaultMatchWidth:"any",parsePatterns:lr,defaultParseWidth:"any"}
)}
,cr={
code:"en-US",formatDistance:qs,formatLong:Is,formatRelative:Ls,localize:Ys,match:dr,options:{
weekStartsOn:0,firstWeekContainsDate:1}
}
;
function mr(t){
const s=R(t);
return Ps(s,Os(s))+1}
function ur(t){
const s=R(t),a=+me(s)-+As(s);
return Math.round(a/ot)+1}
function lt(t,s){
const a=R(t),r=a.getFullYear(),o=xe(),n=s?.firstWeekContainsDate??s?.locale?.options?.firstWeekContainsDate??o.firstWeekContainsDate??o.locale?.options?.firstWeekContainsDate??1,l=Q(t,0);
l.setFullYear(r+1,0,n),l.setHours(0,0,0,0);
const i=le(l,s),d=Q(t,0);
d.setFullYear(r,0,n),d.setHours(0,0,0,0);
const m=le(d,s);
return a.getTime()>=i.getTime()?r+1:a.getTime()>=m.getTime()?r:r-1}
function xr(t,s){
const a=xe(),r=s?.firstWeekContainsDate??s?.locale?.options?.firstWeekContainsDate??a.firstWeekContainsDate??a.locale?.options?.firstWeekContainsDate??1,o=lt(t,s),n=Q(t,0);
return n.setFullYear(o,0,r),n.setHours(0,0,0,0),le(n,s)}
function hr(t,s){
const a=R(t),r=+le(a,s)-+xr(a,s);
return Math.round(r/ot)+1}
function M(t,s){
const a=t<0?"-":"",r=Math.abs(t).toString().padStart(s,"0");
return a+r}
const Y={
y(t,s){
const a=t.getFullYear(),r=a>0?a:1-a;
return M(s==="yy"?r%100:r,s.length)}
,M(t,s){
const a=t.getMonth();
return s==="M"?String(a+1):M(a+1,2)}
,d(t,s){
return M(t.getDate(),s.length)}
,a(t,s){
const a=t.getHours()/12>=1?"pm":"am";
switch(s){
case"a":case"aa":return a.toUpperCase();
case"aaa":return a;
case"aaaaa":return a[0];
case"aaaa":default:return a==="am"?"a.m.":"p.m."}
}
,h(t,s){
return M(t.getHours()%12||12,s.length)}
,H(t,s){
return M(t.getHours(),s.length)}
,m(t,s){
return M(t.getMinutes(),s.length)}
,s(t,s){
return M(t.getSeconds(),s.length)}
,S(t,s){
const a=s.length,r=t.getMilliseconds(),o=Math.trunc(r*Math.pow(10,a-3));
return M(o,s.length)}
}
,J={
am:"am",pm:"pm",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"}
,Oe={
G:function(t,s,a){
const r=t.getFullYear()>0?1:0;
switch(s){
case"G":case"GG":case"GGG":return a.era(r,{
width:"abbreviated"}
);
case"GGGGG":return a.era(r,{
width:"narrow"}
);
case"GGGG":default:return a.era(r,{
width:"wide"}
)}
}
,y:function(t,s,a){
if(s==="yo"){
const r=t.getFullYear(),o=r>0?r:1-r;
return a.ordinalNumber(o,{
unit:"year"}
)}
return Y.y(t,s)}
,Y:function(t,s,a,r){
const o=lt(t,r),n=o>0?o:1-o;
if(s==="YY"){
const l=n%100;
return M(l,2)}
return s==="Yo"?a.ordinalNumber(n,{
unit:"year"}
):M(n,s.length)}
,R:function(t,s){
const a=nt(t);
return M(a,s.length)}
,u:function(t,s){
const a=t.getFullYear();
return M(a,s.length)}
,Q:function(t,s,a){
const r=Math.ceil((t.getMonth()+1)/3);
switch(s){
case"Q":return String(r);
case"QQ":return M(r,2);
case"Qo":return a.ordinalNumber(r,{
unit:"quarter"}
);
case"QQQ":return a.quarter(r,{
width:"abbreviated",context:"formatting"}
);
case"QQQQQ":return a.quarter(r,{
width:"narrow",context:"formatting"}
);
case"QQQQ":default:return a.quarter(r,{
width:"wide",context:"formatting"}
)}
}
,q:function(t,s,a){
const r=Math.ceil((t.getMonth()+1)/3);
switch(s){
case"q":return String(r);
case"qq":return M(r,2);
case"qo":return a.ordinalNumber(r,{
unit:"quarter"}
);
case"qqq":return a.quarter(r,{
width:"abbreviated",context:"standalone"}
);
case"qqqqq":return a.quarter(r,{
width:"narrow",context:"standalone"}
);
case"qqqq":default:return a.quarter(r,{
width:"wide",context:"standalone"}
)}
}
,M:function(t,s,a){
const r=t.getMonth();
switch(s){
case"M":case"MM":return Y.M(t,s);
case"Mo":return a.ordinalNumber(r+1,{
unit:"month"}
);
case"MMM":return a.month(r,{
width:"abbreviated",context:"formatting"}
);
case"MMMMM":return a.month(r,{
width:"narrow",context:"formatting"}
);
case"MMMM":default:return a.month(r,{
width:"wide",context:"formatting"}
)}
}
,L:function(t,s,a){
const r=t.getMonth();
switch(s){
case"L":return String(r+1);
case"LL":return M(r+1,2);
case"Lo":return a.ordinalNumber(r+1,{
unit:"month"}
);
case"LLL":return a.month(r,{
width:"abbreviated",context:"standalone"}
);
case"LLLLL":return a.month(r,{
width:"narrow",context:"standalone"}
);
case"LLLL":default:return a.month(r,{
width:"wide",context:"standalone"}
)}
}
,w:function(t,s,a,r){
const o=hr(t,r);
return s==="wo"?a.ordinalNumber(o,{
unit:"week"}
):M(o,s.length)}
,I:function(t,s,a){
const r=ur(t);
return s==="Io"?a.ordinalNumber(r,{
unit:"week"}
):M(r,s.length)}
,d:function(t,s,a){
return s==="do"?a.ordinalNumber(t.getDate(),{
unit:"date"}
):Y.d(t,s)}
,D:function(t,s,a){
const r=mr(t);
return s==="Do"?a.ordinalNumber(r,{
unit:"dayOfYear"}
):M(r,s.length)}
,E:function(t,s,a){
const r=t.getDay();
switch(s){
case"E":case"EE":case"EEE":return a.day(r,{
width:"abbreviated",context:"formatting"}
);
case"EEEEE":return a.day(r,{
width:"narrow",context:"formatting"}
);
case"EEEEEE":return a.day(r,{
width:"short",context:"formatting"}
);
case"EEEE":default:return a.day(r,{
width:"wide",context:"formatting"}
)}
}
,e:function(t,s,a,r){
const o=t.getDay(),n=(o-r.weekStartsOn+8)%7||7;
switch(s){
case"e":return String(n);
case"ee":return M(n,2);
case"eo":return a.ordinalNumber(n,{
unit:"day"}
);
case"eee":return a.day(o,{
width:"abbreviated",context:"formatting"}
);
case"eeeee":return a.day(o,{
width:"narrow",context:"formatting"}
);
case"eeeeee":return a.day(o,{
width:"short",context:"formatting"}
);
case"eeee":default:return a.day(o,{
width:"wide",context:"formatting"}
)}
}
,c:function(t,s,a,r){
const o=t.getDay(),n=(o-r.weekStartsOn+8)%7||7;
switch(s){
case"c":return String(n);
case"cc":return M(n,s.length);
case"co":return a.ordinalNumber(n,{
unit:"day"}
);
case"ccc":return a.day(o,{
width:"abbreviated",context:"standalone"}
);
case"ccccc":return a.day(o,{
width:"narrow",context:"standalone"}
);
case"cccccc":return a.day(o,{
width:"short",context:"standalone"}
);
case"cccc":default:return a.day(o,{
width:"wide",context:"standalone"}
)}
}
,i:function(t,s,a){
const r=t.getDay(),o=r===0?7:r;
switch(s){
case"i":return String(o);
case"ii":return M(o,s.length);
case"io":return a.ordinalNumber(o,{
unit:"day"}
);
case"iii":return a.day(r,{
width:"abbreviated",context:"formatting"}
);
case"iiiii":return a.day(r,{
width:"narrow",context:"formatting"}
);
case"iiiiii":return a.day(r,{
width:"short",context:"formatting"}
);
case"iiii":default:return a.day(r,{
width:"wide",context:"formatting"}
)}
}
,a:function(t,s,a){
const o=t.getHours()/12>=1?"pm":"am";
switch(s){
case"a":case"aa":return a.dayPeriod(o,{
width:"abbreviated",context:"formatting"}
);
case"aaa":return a.dayPeriod(o,{
width:"abbreviated",context:"formatting"}
).toLowerCase();
case"aaaaa":return a.dayPeriod(o,{
width:"narrow",context:"formatting"}
);
case"aaaa":default:return a.dayPeriod(o,{
width:"wide",context:"formatting"}
)}
}
,b:function(t,s,a){
const r=t.getHours();
let o;
switch(r===12?o=J.noon:r===0?o=J.midnight:o=r/12>=1?"pm":"am",s){
case"b":case"bb":return a.dayPeriod(o,{
width:"abbreviated",context:"formatting"}
);
case"bbb":return a.dayPeriod(o,{
width:"abbreviated",context:"formatting"}
).toLowerCase();
case"bbbbb":return a.dayPeriod(o,{
width:"narrow",context:"formatting"}
);
case"bbbb":default:return a.dayPeriod(o,{
width:"wide",context:"formatting"}
)}
}
,B:function(t,s,a){
const r=t.getHours();
let o;
switch(r>=17?o=J.evening:r>=12?o=J.afternoon:r>=4?o=J.morning:o=J.night,s){
case"B":case"BB":case"BBB":return a.dayPeriod(o,{
width:"abbreviated",context:"formatting"}
);
case"BBBBB":return a.dayPeriod(o,{
width:"narrow",context:"formatting"}
);
case"BBBB":default:return a.dayPeriod(o,{
width:"wide",context:"formatting"}
)}
}
,h:function(t,s,a){
if(s==="ho"){
let r=t.getHours()%12;
return r===0&&(r=12),a.ordinalNumber(r,{
unit:"hour"}
)}
return Y.h(t,s)}
,H:function(t,s,a){
return s==="Ho"?a.ordinalNumber(t.getHours(),{
unit:"hour"}
):Y.H(t,s)}
,K:function(t,s,a){
const r=t.getHours()%12;
return s==="Ko"?a.ordinalNumber(r,{
unit:"hour"}
):M(r,s.length)}
,k:function(t,s,a){
let r=t.getHours();
return r===0&&(r=24),s==="ko"?a.ordinalNumber(r,{
unit:"hour"}
):M(r,s.length)}
,m:function(t,s,a){
return s==="mo"?a.ordinalNumber(t.getMinutes(),{
unit:"minute"}
):Y.m(t,s)}
,s:function(t,s,a){
return s==="so"?a.ordinalNumber(t.getSeconds(),{
unit:"second"}
):Y.s(t,s)}
,S:function(t,s){
return Y.S(t,s)}
,X:function(t,s,a){
const r=t.getTimezoneOffset();
if(r===0)return"Z";
switch(s){
case"X":return qe(r);
case"XXXX":case"XX":return U(r);
case"XXXXX":case"XXX":default:return U(r,":")}
}
,x:function(t,s,a){
const r=t.getTimezoneOffset();
switch(s){
case"x":return qe(r);
case"xxxx":case"xx":return U(r);
case"xxxxx":case"xxx":default:return U(r,":")}
}
,O:function(t,s,a){
const r=t.getTimezoneOffset();
switch(s){
case"O":case"OO":case"OOO":return"GMT"+De(r,":");
case"OOOO":default:return"GMT"+U(r,":")}
}
,z:function(t,s,a){
const r=t.getTimezoneOffset();
switch(s){
case"z":case"zz":case"zzz":return"GMT"+De(r,":");
case"zzzz":default:return"GMT"+U(r,":")}
}
,t:function(t,s,a){
const r=Math.trunc(t.getTime()/1e3);
return M(r,s.length)}
,T:function(t,s,a){
const r=t.getTime();
return M(r,s.length)}
}
;
function De(t,s=""){
const a=t>0?"-":"+",r=Math.abs(t),o=Math.trunc(r/60),n=r%60;
return n===0?a+String(o):a+String(o)+s+M(n,2)}
function qe(t,s){
return t%60===0?(t>0?"-":"+")+M(Math.abs(t)/60,2):U(t,s)}
function U(t,s=""){
const a=t>0?"-":"+",r=Math.abs(t),o=M(Math.trunc(r/60),2),n=M(r%60,2);
return a+o+s+n}
const Te=(t,s)=>{
switch(t){
case"P":return s.date({
width:"short"}
);
case"PP":return s.date({
width:"medium"}
);
case"PPP":return s.date({
width:"long"}
);
case"PPPP":default:return s.date({
width:"full"}
)}
}
,dt=(t,s)=>{
switch(t){
case"p":return s.time({
width:"short"}
);
case"pp":return s.time({
width:"medium"}
);
case"ppp":return s.time({
width:"long"}
);
case"pppp":default:return s.time({
width:"full"}
)}
}
,pr=(t,s)=>{
const a=t.match(/(P+)(p+)?/)||[],r=a[1],o=a[2];
if(!o)return Te(t,s);
let n;
switch(r){
case"P":n=s.dateTime({
width:"short"}
);
break;
case"PP":n=s.dateTime({
width:"medium"}
);
break;
case"PPP":n=s.dateTime({
width:"long"}
);
break;
case"PPPP":default:n=s.dateTime({
width:"full"}
);
break}
return n.replace("{
{
date}
}
",Te(r,s)).replace("{
{
time}
}
",dt(o,s))}
,fr={
p:dt,P:pr}
,gr=/^D+$/,br=/^Y+$/,vr=["D","DD","YY","YYYY"];
function yr(t){
return gr.test(t)}
function jr(t){
return br.test(t)}
function wr(t,s,a){
const r=Nr(t,s,a);
if(console.warn(r),vr.includes(t))throw new RangeError(r)}
function Nr(t,s,a){
const r=t[0]==="Y"?"years":"days of the month";
return`Use \`${
t.toLowerCase()}
\` instead of \`${
t}
\` (in \`${
s}
\`) for formatting ${
r}
 to the input \`${
a}
\`;
 see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md`}
const kr=/[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g,Sr=/P+p+|P+|p+|''|'(''|[^'])+('|$)|./g,Mr=/^'([^]*?)'?$/,Cr=/''/g,Pr=/[a-zA-Z]/;
function ne(t,s,a){
const r=xe(),o=a?.locale??r.locale??cr,n=a?.firstWeekContainsDate??a?.locale?.options?.firstWeekContainsDate??r.firstWeekContainsDate??r.locale?.options?.firstWeekContainsDate??1,l=a?.weekStartsOn??a?.locale?.options?.weekStartsOn??r.weekStartsOn??r.locale?.options?.weekStartsOn??0,i=R(t);
if(!zs(i))throw new RangeError("Invalid time value");
let d=s.match(Sr).map(c=>{
const u=c[0];
if(u==="p"||u==="P"){
const f=fr[u];
return f(c,o.formatLong)}
return c}
).join("").match(kr).map(c=>{
if(c==="''")return{
isToken:!1,value:"'"}
;
const u=c[0];
if(u==="'")return{
isToken:!1,value:Ar(c)}
;
if(Oe[u])return{
isToken:!0,value:c}
;
if(u.match(Pr))throw new RangeError("Format string contains an unescaped latin alphabet character `"+u+"`");
return{
isToken:!1,value:c}
}
);
o.localize.preprocessor&&(d=o.localize.preprocessor(i,d));
const m={
firstWeekContainsDate:n,weekStartsOn:l,locale:o}
;
return d.map(c=>{
if(!c.isToken)return c.value;
const u=c.value;
(!a?.useAdditionalWeekYearTokens&&jr(u)||!a?.useAdditionalDayOfYearTokens&&yr(u))&&wr(u,s,String(t));
const f=Oe[u[0]];
return f(i,u,o.localize,m)}
).join("")}
function Ar(t){
const s=t.match(Mr);
return s?s[1].replace(Cr,"'"):t}
const Er={
lessThanXSeconds:{
one:"menos de um segundo",other:"menos de {
{
count}
}
 segundos"}
,xSeconds:{
one:"1 segundo",other:"{
{
count}
}
 segundos"}
,halfAMinute:"meio minuto",lessThanXMinutes:{
one:"menos de um minuto",other:"menos de {
{
count}
}
 minutos"}
,xMinutes:{
one:"1 minuto",other:"{
{
count}
}
 minutos"}
,aboutXHours:{
one:"cerca de 1 hora",other:"cerca de {
{
count}
}
 horas"}
,xHours:{
one:"1 hora",other:"{
{
count}
}
 horas"}
,xDays:{
one:"1 dia",other:"{
{
count}
}
 dias"}
,aboutXWeeks:{
one:"cerca de 1 semana",other:"cerca de {
{
count}
}
 semanas"}
,xWeeks:{
one:"1 semana",other:"{
{
count}
}
 semanas"}
,aboutXMonths:{
one:"cerca de 1 mês",other:"cerca de {
{
count}
}
 meses"}
,xMonths:{
one:"1 mês",other:"{
{
count}
}
 meses"}
,aboutXYears:{
one:"cerca de 1 ano",other:"cerca de {
{
count}
}
 anos"}
,xYears:{
one:"1 ano",other:"{
{
count}
}
 anos"}
,overXYears:{
one:"mais de 1 ano",other:"mais de {
{
count}
}
 anos"}
,almostXYears:{
one:"quase 1 ano",other:"quase {
{
count}
}
 anos"}
}
,zr=(t,s,a)=>{
let r;
const o=Er[t];
return typeof o=="string"?r=o:s===1?r=o.one:r=o.other.replace("{
{
count}
}
",String(s)),a?.addSuffix?a.comparison&&a.comparison>0?"em "+r:"há "+r:r}
,Or={
full:"EEEE, d 'de' MMMM 'de' y",long:"d 'de' MMMM 'de' y",medium:"d MMM y",short:"dd/MM/yyyy"}
,Dr={
full:"HH:mm:ss zzzz",long:"HH:mm:ss z",medium:"HH:mm:ss",short:"HH:mm"}
,qr={
full:"{
{
date}
}
 'às' {
{
time}
}
",long:"{
{
date}
}
 'às' {
{
time}
}
",medium:"{
{
date}
}
, {
{
time}
}
",short:"{
{
date}
}
, {
{
time}
}
"}
,Tr={
date:ee({
formats:Or,defaultWidth:"full"}
),time:ee({
formats:Dr,defaultWidth:"full"}
),dateTime:ee({
formats:qr,defaultWidth:"full"}
)}
,Wr={
lastWeek:t=>{
const s=t.getDay();
return"'"+(s===0||s===6?"último":"última")+"' eeee 'às' p"}
,yesterday:"'ontem às' p",today:"'hoje às' p",tomorrow:"'amanhã às' p",nextWeek:"eeee 'às' p",other:"P"}
,Br=(t,s,a,r)=>{
const o=Wr[t];
return typeof o=="function"?o(s):o}
,Ir={
narrow:["AC","DC"],abbreviated:["AC","DC"],wide:["antes de cristo","depois de cristo"]}
,Rr={
narrow:["1","2","3","4"],abbreviated:["T1","T2","T3","T4"],wide:["1º trimestre","2º trimestre","3º trimestre","4º trimestre"]}
,Lr={
narrow:["j","f","m","a","m","j","j","a","s","o","n","d"],abbreviated:["jan","fev","mar","abr","mai","jun","jul","ago","set","out","nov","dez"],wide:["janeiro","fevereiro","março","abril","maio","junho","julho","agosto","setembro","outubro","novembro","dezembro"]}
,$r={
narrow:["D","S","T","Q","Q","S","S"],short:["dom","seg","ter","qua","qui","sex","sab"],abbreviated:["domingo","segunda","terça","quarta","quinta","sexta","sábado"],wide:["domingo","segunda-feira","terça-feira","quarta-feira","quinta-feira","sexta-feira","sábado"]}
,Fr={
narrow:{
am:"a",pm:"p",midnight:"mn",noon:"md",morning:"manhã",afternoon:"tarde",evening:"tarde",night:"noite"}
,abbreviated:{
am:"AM",pm:"PM",midnight:"meia-noite",noon:"meio-dia",morning:"manhã",afternoon:"tarde",evening:"tarde",night:"noite"}
,wide:{
am:"a.m.",pm:"p.m.",midnight:"meia-noite",noon:"meio-dia",morning:"manhã",afternoon:"tarde",evening:"tarde",night:"noite"}
}
,Xr={
narrow:{
am:"a",pm:"p",midnight:"mn",noon:"md",morning:"da manhã",afternoon:"da tarde",evening:"da tarde",night:"da noite"}
,abbreviated:{
am:"AM",pm:"PM",midnight:"meia-noite",noon:"meio-dia",morning:"da manhã",afternoon:"da tarde",evening:"da tarde",night:"da noite"}
,wide:{
am:"a.m.",pm:"p.m.",midnight:"meia-noite",noon:"meio-dia",morning:"da manhã",afternoon:"da tarde",evening:"da tarde",night:"da noite"}
}
,Hr=(t,s)=>{
const a=Number(t);
return s?.unit==="week"?a+"ª":a+"º"}
,Vr={
ordinalNumber:Hr,era:$({
values:Ir,defaultWidth:"wide"}
),quarter:$({
values:Rr,defaultWidth:"wide",argumentCallback:t=>t-1}
),month:$({
values:Lr,defaultWidth:"wide"}
),day:$({
values:$r,defaultWidth:"wide"}
),dayPeriod:$({
values:Fr,defaultWidth:"wide",formattingValues:Xr,defaultFormattingWidth:"wide"}
)}
,_r=/^(\d+)[ºªo]?/i,Gr=/\d+/i,Yr={
narrow:/^(ac|dc|a|d)/i,abbreviated:/^(a\.?\s?c\.?|d\.?\s?c\.?)/i,wide:/^(antes de cristo|depois de cristo)/i}
,Qr={
any:[/^ac/i,/^dc/i],wide:[/^antes de cristo/i,/^depois de cristo/i]}
,Ur={
narrow:/^[1234]/i,abbreviated:/^T[1234]/i,wide:/^[1234](º)? trimestre/i}
,Zr={
any:[/1/i,/2/i,/3/i,/4/i]}
,Jr={
narrow:/^[jfmajsond]/i,abbreviated:/^(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)/i,wide:/^(janeiro|fevereiro|março|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)/i}
,Kr={
narrow:[/^j/i,/^f/i,/^m/i,/^a/i,/^m/i,/^j/i,/^j/i,/^a/i,/^s/i,/^o/i,/^n/i,/^d/i],any:[/^ja/i,/^fev/i,/^mar/i,/^abr/i,/^mai/i,/^jun/i,/^jul/i,/^ago/i,/^set/i,/^out/i,/^nov/i,/^dez/i]}
,eo={
narrow:/^(dom|[23456]ª?|s[aá]b)/i,short:/^(dom|[23456]ª?|s[aá]b)/i,abbreviated:/^(dom|seg|ter|qua|qui|sex|s[aá]b)/i,wide:/^(domingo|(segunda|ter[cç]a|quarta|quinta|sexta)([- ]feira)?|s[aá]bado)/i}
,to={
short:[/^d/i,/^2/i,/^3/i,/^4/i,/^5/i,/^6/i,/^s[aá]/i],narrow:[/^d/i,/^2/i,/^3/i,/^4/i,/^5/i,/^6/i,/^s[aá]/i],any:[/^d/i,/^seg/i,/^t/i,/^qua/i,/^qui/i,/^sex/i,/^s[aá]b/i]}
,ao={
narrow:/^(a|p|mn|md|(da) (manhã|tarde|noite))/i,any:/^([ap]\.?\s?m\.?|meia[-\s]noite|meio[-\s]dia|(da) (manhã|tarde|noite))/i}
,so={
any:{
am:/^a/i,pm:/^p/i,midnight:/^mn|^meia[-\s]noite/i,noon:/^md|^meio[-\s]dia/i,morning:/manhã/i,afternoon:/tarde/i,evening:/tarde/i,night:/noite/i}
}
,ro={
ordinalNumber:it({
matchPattern:_r,parsePattern:Gr,valueCallback:t=>parseInt(t,10)}
),era:F({
matchPatterns:Yr,defaultMatchWidth:"wide",parsePatterns:Qr,defaultParseWidth:"any"}
),quarter:F({
matchPatterns:Ur,defaultMatchWidth:"wide",parsePatterns:Zr,defaultParseWidth:"any",valueCallback:t=>t+1}
),month:F({
matchPatterns:Jr,defaultMatchWidth:"wide",parsePatterns:Kr,defaultParseWidth:"any"}
),day:F({
matchPatterns:eo,defaultMatchWidth:"wide",parsePatterns:to,defaultParseWidth:"any"}
),dayPeriod:F({
matchPatterns:ao,defaultMatchWidth:"any",parsePatterns:so,defaultParseWidth:"any"}
)}
,je={
code:"pt-BR",formatDistance:zr,formatLong:Tr,formatRelative:Br,localize:Vr,match:ro,options:{
weekStartsOn:0,firstWeekContainsDate:1}
}
,Qo=({
onSelect:t,onBack:s}
)=>{
const a=ye(new Date,21),r=ne(a,"dd 'de' MMMM",{
locale:je}
),o=[{
id:"decidida",label:"Eu sei que consigo!",icon:os}
,{
id:"disposta",label:"Estou disposta a tentar algo novo!",icon:be}
,{
id:"insegura",label:"Ainda sinto insegurança, mas quero mudar!",icon:Ue}
];
return e.jsx(v,{
step:32,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsxs("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-6 text-center",children:["Quão confiante você está em entrar em forma até o dia"," ",e.jsx("span",{
className:"text-primary",children:r}
),"?"]}
),e.jsx("div",{
className:"space-y-3",children:o.map(n=>{
const l=n.icon;
return e.jsx(P,{
onClick:()=>t(n.id),icon:e.jsx(l,{
className:"w-5 h-5"}
),showArrow:!0,children:n.label}
,n.id)}
)}
)]}
)}
)}
)}
,Uo=({
onComplete:t,onBack:s}
)=>{
const[a,r]=h.useState(0),[o,n]=h.useState(0),l=[Zt,Jt,Kt];
return h.useEffect(()=>{
const i=setInterval(()=>{
r(m=>m>=100?(clearInterval(i),setTimeout(t,500),100):m+1)}
,60),d=setInterval(()=>{
n(m=>(m+1)%l.length)}
,2e3);
return()=>{
clearInterval(i),clearInterval(d)}
}
,[t]),e.jsx(v,{
step:33,totalSteps:35,showProgress:!1,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto text-center",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-6",children:"Aguarde, estamos criando seu plano personalizado"}
),e.jsxs("div",{
className:"mb-2",children:[e.jsx("div",{
className:"w-full h-3 bg-muted rounded-full overflow-hidden",children:e.jsx("div",{
className:"h-full bg-primary transition-all duration-200 rounded-full",style:{
width:`${
a}
%`}
}
)}
),e.jsxs("p",{
className:"text-lg font-semibold text-foreground mt-2",children:[a,"%"]}
)]}
),e.jsx("div",{
className:"mt-6 animate-fade-in rounded-2xl overflow-hidden",children:e.jsx("img",{
src:l[o],alt:"Transformação",className:"w-full max-h-[50vh] object-contain",loading:"eager",decoding:"async",fetchPriority:"high"}
)}
,o),e.jsx("p",{
className:"text-xs text-muted-foreground mt-4",children:"Resultados reais de usuárias do programa."}
)]}
)}
)}
)}
,Zo=({
onContinue:t,onBack:s}
)=>{
const[a,r]=h.useState(""),o=/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(a);
return e.jsx(v,{
step:34,totalSteps:35,showBack:!0,onBack:s,children:e.jsx("div",{
className:"flex-1 px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-xl md:text-2xl font-bold text-foreground mb-2 text-center",children:"Digite seu e-mail"}
),e.jsx("p",{
className:"text-muted-foreground mb-6 text-center text-sm",children:"Desbloqueie o acesso ao seu plano de Calistenia Asiática Atlas"}
),e.jsx("div",{
className:"mb-6",children:e.jsx("input",{
type:"email",value:a,onChange:n=>r(n.target.value),placeholder:"Digite seu e-mail",className:"w-full px-4 py-4 rounded-xl border-2 border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"}
)}
),e.jsxs("p",{
className:"text-xs text-muted-foreground mb-6 text-center",children:["Respeitamos sua privacidade e levamos sua proteção muito a sério - sem spam."," ",e.jsx("a",{
href:"#",className:"underline",children:"Política de privacidade"}
),"."]}
),e.jsxs("div",{
className:"bg-blue-50 dark:bg-blue-900/20 rounded-xl p-4 mb-6 flex items-center gap-3",children:[e.jsx(us,{
className:"w-8 h-8 text-blue-500"}
),e.jsx("p",{
className:"text-sm font-medium text-foreground",children:"5 milhões mulheres já aderiram"}
)]}
),e.jsx(O,{
onClick:()=>t(a),disabled:!o,children:"Obter meu plano"}
)]}
)}
)}
)}
,Jo=({
onContinue:t,onBack:s,currentWeight:a,targetWeight:r,height:o,motivationReal:n,commitmentLevel:l}
)=>{
const i=o/100,d=a/(i*i),m=()=>d>=30?ta:d>=27?aa:d>=25?sa:ra,c=ye(new Date,21),u=ne(c,"dd 'de' MMMM",{
locale:je}
),f=()=>({
confiante:"Autoestima e confiança corporal.",energia:"Vitalidade máxima e fim do cansaço metabólico.",roupas:"Redução de medidas e ajuste perfeito das roupas.","pos-parto":"Recuperação abdominal e tônus pós-gestação.",outro:"Transformação estética e saúde metabólica."}
)[n||""]||"Transformação estética e saúde metabólica.",N=()=>({
decidida:`Sua mentalidade forte acelerará a ativação das fibras profundas. Sua primeira grande transformação está prevista para o dia ${
u}
.`,disposta:`O Protocolo foi ajustado para garantir sua constância. Você atingirá o pico de queima metabólica até o dia ${
u}
.`,insegura:`Não se preocupe, o método é simples e sem impacto. Sua nova versão começará a ser visível no dia ${
u}
.`}
)[l||""]||`Sua transformação está prevista para o dia ${
u}
.`;
return e.jsxs("div",{
className:"h-screen bg-background flex flex-col overflow-hidden",children:[e.jsx(Be,{
showBack:!0,onBack:s}
),e.jsx("main",{
className:"flex-1 overflow-y-auto px-4 py-6 pb-24",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsxs("h1",{
className:"font-bold text-foreground mb-4 text-center md:text-2xl text-xl",children:["Seu plano de Calistenia Asiática Atlas está ",e.jsx("span",{
className:"text-primary",children:"Quase"}
)," pronto!"]}
),e.jsxs("div",{
className:"bg-card rounded-xl p-4 mb-6 quiz-shadow",children:[e.jsxs("div",{
className:"flex items-center justify-between mb-3",children:[e.jsx("div",{
className:"flex-1 text-center",children:e.jsx("span",{
className:"text-sm text-muted-foreground font-medium",children:"Agora"}
)}
),e.jsx("div",{
className:"w-16"}
),e.jsx("div",{
className:"flex-1 text-center",children:e.jsx("span",{
className:"text-sm text-muted-foreground font-medium",children:"Seu objetivo"}
)}
)]}
),e.jsxs("div",{
className:"flex items-center justify-center gap-2",children:[e.jsx("div",{
className:"flex-1 flex justify-center",children:e.jsx("img",{
src:m(),alt:"Antes",className:"w-[140px] h-[168px] md:w-48 md:h-56 object-cover object-top rounded-lg"}
)}
),e.jsx("div",{
className:"flex items-center justify-center text-4xl text-muted-foreground font-bold",children:e.jsxs("span",{
className:"flex",children:[e.jsx("span",{
className:"animate-[fade-in_0.5s_ease-out_0s_infinite_alternate] opacity-40",children:"›"}
),e.jsx("span",{
className:"animate-[fade-in_0.5s_ease-out_0.15s_infinite_alternate] opacity-60",children:"›"}
),e.jsx("span",{
className:"animate-[fade-in_0.5s_ease-out_0.3s_infinite_alternate] opacity-100",children:"›"}
)]}
)}
),e.jsx("div",{
className:"flex-1 flex justify-center",children:e.jsx("img",{
src:ea,alt:"Depois",className:"w-[140px] h-[168px] md:w-48 md:h-56 object-cover object-top rounded-lg"}
)}
)]}
),e.jsxs("div",{
className:"grid grid-cols-2 gap-4 mt-4 pt-4 border-t border-border",children:[e.jsxs("div",{
className:"space-y-3",children:[e.jsxs("div",{
children:[e.jsx("p",{
className:"text-xs text-primary font-medium mb-0.5",children:"Peso atual"}
),e.jsxs("p",{
className:"text-lg font-bold text-foreground",children:[a," kg"]}
)]}
),e.jsxs("div",{
children:[e.jsx("p",{
className:"text-xs text-primary font-medium mb-0.5",children:"Gordura corporal"}
),e.jsx("p",{
className:"text-sm font-bold text-foreground",children:"Acima do normal"}
)]}
),e.jsxs("div",{
children:[e.jsx("p",{
className:"text-xs text-primary font-medium mb-0.5",children:"Nível de treino de calistenia"}
),e.jsx("p",{
className:"text-sm font-bold text-foreground mb-1.5",children:"Iniciante"}
),e.jsxs("div",{
className:"flex gap-1",children:[e.jsx("div",{
className:"h-1.5 flex-1 rounded-full bg-primary"}
),e.jsx("div",{
className:"h-1.5 flex-1 rounded-full bg-muted"}
),e.jsx("div",{
className:"h-1.5 flex-1 rounded-full bg-muted"}
)]}
)]}
)]}
),e.jsxs("div",{
className:"space-y-3",children:[e.jsxs("div",{
children:[e.jsx("p",{
className:"text-xs text-primary font-medium mb-0.5",children:"Peso desejado"}
),e.jsxs("p",{
className:"text-lg font-bold text-primary",children:[r," kg"]}
)]}
),e.jsxs("div",{
children:[e.jsx("p",{
className:"text-xs text-primary font-medium mb-0.5",children:"Gordura corporal"}
),e.jsx("p",{
className:"text-sm font-bold text-foreground",children:"Normal"}
)]}
),e.jsxs("div",{
children:[e.jsx("p",{
className:"text-xs text-primary font-medium mb-0.5",children:"Nível de treino de calistenia"}
),e.jsx("p",{
className:"text-sm font-bold text-foreground mb-1.5",children:"Avançado"}
),e.jsxs("div",{
className:"flex gap-1",children:[e.jsx("div",{
className:"h-1.5 flex-1 rounded-full bg-primary"}
),e.jsx("div",{
className:"h-1.5 flex-1 rounded-full bg-primary"}
),e.jsx("div",{
className:"h-1.5 flex-1 rounded-full bg-primary"}
)]}
)]}
)]}
)]}
)]}
),e.jsxs("div",{
className:"space-y-3 mb-6",children:[e.jsxs("div",{
className:"bg-primary/10 border border-primary/20 rounded-xl p-3 flex items-start gap-2.5",children:[e.jsx(ls,{
className:"w-5 h-5 text-primary flex-shrink-0 mt-0.5"}
),e.jsxs("p",{
className:"text-sm text-foreground",children:[e.jsx("span",{
className:"font-bold text-primary",children:"Foco do Protocolo:"}
)," ",f()]}
)]}
),e.jsxs("div",{
className:"bg-accent border border-border rounded-xl p-3 flex items-start gap-2.5",children:[e.jsx(Ye,{
className:"w-5 h-5 text-primary flex-shrink-0 mt-0.5"}
),e.jsx("p",{
className:"text-sm text-foreground leading-relaxed",children:N()}
)]}
)]}
),e.jsx("div",{
className:"bg-muted/50 border border-border rounded-xl p-3 mb-6 text-center",children:e.jsxs("p",{
className:"text-sm text-muted-foreground",children:["🧘 Método ",e.jsx("span",{
className:"font-semibold text-foreground",children:"sem impacto"}
)," — seguro para qualquer idade e condição física"]}
)}
)]}
)}
),e.jsx("div",{
className:"fixed bottom-0 left-0 right-0 p-4 z-50",children:e.jsx("div",{
className:"max-w-md mx-auto",children:e.jsx(O,{
onClick:t,children:"CONTINUAR"}
)}
)}
)]}
)}
,oo="/assets/app-mockup-B3X03Zx2.webp",Ko=({
onBack:t,currentWeight:s,targetWeight:a,height:r,motivationReal:o,commitmentLevel:n,energyLevel:l,hasLimitations:i}
)=>{
const[d,m]=h.useState(null),[c,u]=h.useState({
minutes:10,seconds:0}
),[f,N]=h.useState(7),[j,w]=h.useState(()=>localStorage.getItem("offer_revealed")==="true");
h.useEffect(()=>{
if(j)return;
const x=setTimeout(()=>{
w(!0),localStorage.setItem("offer_revealed","true")}
,323e3);
return()=>clearTimeout(x)}
,[j]);
const y=x=>x?x.startsWith("?")?x:`?${
x}
`:"",E=(()=>{
const x="https://lastlink.com/p/C680AA305/checkout-payment/",T=y(localStorage.getItem("utm_querystring"));
return`${
x}
${
T}
`}
)();
h.useEffect(()=>{
const T=document.getElementById("vturb-container");
if(!T)return;
const L=document.createElement("vturb-smartplayer");
L.id="vid-69cd7dd6181cf0419855d464",L.style.cssText="display:block;
margin:0 auto;
width:100%;
max-width:400px;
",T.appendChild(L);
const de=setTimeout(()=>{
if(!document.querySelector('script[src*="69cd7dd6181cf0419855d464"]')){
const Z=document.createElement("script");
Z.src="https://scripts.converteai.net/e6e99317-bea5-4278-a04d-e7732bc0fcb1/players/69cd7dd6181cf0419855d464/v4/player.js",Z.async=!0,document.head.appendChild(Z)}
}
,100);
return()=>{
clearTimeout(de),T&&(T.innerHTML="");
const V=document.querySelector('script[src*="69cd7dd6181cf0419855d464"]');
V&&V.remove()}
}
,[]),h.useEffect(()=>{
if(!j)return;
const x=setInterval(()=>{
u(T=>T.minutes===0&&T.seconds===0?(clearInterval(x),T):T.seconds===0?{
minutes:T.minutes-1,seconds:59}
:{
...T,seconds:T.seconds-1}
)}
,1e3);
return()=>clearInterval(x)}
,[j]),h.useEffect(()=>{
const x=Math.floor(Math.random()*45001)+45e3,T=setTimeout(()=>{
N(L=>Math.max(L-1,6))}
,x);
return()=>clearTimeout(T)}
,[]);
const D=r/100,z=s/(D*D),W=ye(new Date,21),p=ne(W,"dd 'de' MMMM",{
locale:je}
),S=297,q=37.9,B=(()=>{
const x=[];
return x.push({
title:"Ativação das Fibras Profundas",description:"o segredo asiático para destravar o metabolismo e queimar gordura de verdade, sem precisar se matar na academia."}
),x.push({
title:'Cronograma "Barriga Chapada" em 21 Dias',description:`um passo a passo diário e direto ao ponto para você saber exatamente o que fazer até o dia ${
p}
.`}
),x.push({
title:"Guia de Alimentação Metabólica",description:"receitas práticas e gostosas para acelerar a queima de gordura enquanto você descansa."}
),z>25||i?x.push({
title:"Recuperação e Alívio Articular",description:"exercícios suaves e sem impacto feitos para fortalecer suas articulações e eliminar dores enquanto você elimina peso."}
):x.push({
title:"Protocolo de Tônus e Definição",description:"foco total em deixar o corpo durinho, aumentar a flexibilidade e conquistar a tão sonhada barriga chapada."}
),l==="baixo"||l==="queda"?x.push({
title:"Explosão de Vitalidade",description:"técnicas de ativação que combatem o cansaço constante e devolvem sua disposição logo nos primeiros dias."}
):x.push({
title:"Rotinas de Alta Performance",description:"treinos rápidos de 10 a 20 minutos que se encaixam na sua correria para manter o metabolismo acelerado o dia todo."}
),x}
)(),I=[{
id:"exercicios",question:"Quais exercícios a Calistenia inclui?",answer:"Os exercícios de Calistenia se concentram em usar o peso do próprio corpo para ganhar força e flexibilidade, incluindo variações de agachamentos, pranchas, flexões adaptadas e movimentos de mobilidade."}
,{
id:"programa",question:"Como vou descobrir qual programa é ideal para mim?",answer:"Nosso quiz personalizado analisa suas respostas e cria um programa sob medida para suas necessidades, considerando sua idade, objetivos e limitações físicas."}
,{
id:"acesso",question:"Como posso acessar meu plano?",answer:"Após a compra, você receberá acesso imediato ao seu plano personalizado através do nosso aplicativo ou plataforma web."}
];
return e.jsxs("div",{
className:`min-h-screen bg-background ${
j?"pt-10":""}
`,children:[j&&e.jsxs("div",{
className:"animate-fade-in bg-primary text-primary-foreground py-2 px-4 flex items-center justify-center gap-2 fixed top-0 left-0 right-0 z-50",children:[e.jsx("span",{
className:"text-sm",children:"Oferta expira em:"}
),e.jsxs("span",{
className:"font-bold",children:[String(c.minutes).padStart(2,"0"),":",String(c.seconds).padStart(2,"0")]}
)]}
),e.jsx(Be,{
showBack:!0,onBack:t}
),e.jsx("main",{
className:"px-4 py-6",children:e.jsxs("div",{
className:"max-w-md mx-auto",children:[e.jsx("h1",{
className:"text-2xl md:text-3xl font-bold text-primary mb-2 text-center",children:"Seu plano de Calistenia Asiática está pronto!"}
),e.jsx("p",{
className:"text-sm md:text-base text-muted-foreground mb-6 text-center",children:"Assista ao vídeo abaixo para entender como funciona..."}
),e.jsx("div",{
className:"mb-6 flex justify-center",children:e.jsx("div",{
id:"vturb-container",className:"overflow-hidden rounded-2xl",style:{
minHeight:"250px",width:"100%",maxWidth:"400px"}
}
)}
),j&&e.jsxs("div",{
className:"animate-fade-in",children:[e.jsx("a",{
href:E,target:"_blank",rel:"noopener noreferrer",className:"w-full bg-primary text-primary-foreground py-4 px-6 rounded-xl font-bold text-lg mb-3 hover:bg-primary/90 transition-colors block text-center animate-pulse-shadow",children:"Obter meu plano personalizado agora"}
),e.jsxs("div",{
className:"flex items-center justify-center gap-2 mb-6",children:[e.jsx(ce,{
className:"w-4 h-4 text-orange-500"}
),e.jsxs("span",{
className:"text-sm font-semibold text-orange-600",children:["Restam apenas ",f," vagas"]}
)]}
),e.jsxs("div",{
className:"bg-card rounded-xl p-5 mb-6 quiz-shadow",children:[e.jsx("h2",{
className:"text-sm font-bold text-foreground mb-4 text-center",children:"O que você vai receber"}
),e.jsx("div",{
className:"space-y-3",children:B.map((x,T)=>e.jsxs("div",{
className:"flex items-start gap-2",children:[e.jsx("div",{
className:"w-5 h-5 rounded-md bg-quiz-green flex items-center justify-center flex-shrink-0 mt-0.5",children:e.jsx(Qe,{
className:"w-3 h-3 text-white"}
)}
),e.jsxs("div",{
className:"text-sm",children:[e.jsxs("span",{
className:"font-bold text-foreground",children:[x.title,":"]}
)," ",e.jsx("span",{
className:"text-muted-foreground",children:x.description}
)]}
)]}
,T))}
),e.jsx("div",{
className:"mt-6",children:e.jsx("img",{
src:oo,alt:"Aplicativo Calistenia Asiática Atlas",className:"w-full rounded-2xl",loading:"eager",decoding:"async"}
)}
)]}
),e.jsxs("div",{
className:"bg-card rounded-xl p-5 mb-6 quiz-shadow border-2 border-primary",children:[e.jsxs("div",{
className:"flex items-center justify-center gap-2 mb-3",children:[e.jsx(ce,{
className:"w-4 h-4 text-orange-500"}
),e.jsxs("span",{
className:"text-sm font-semibold text-orange-600",children:["Restam apenas ",f," vagas"]}
)]}
),e.jsxs("div",{
className:"text-center space-y-1",children:[e.jsxs("p",{
className:"text-xl text-muted-foreground",children:["De ",e.jsxs("span",{
className:"line-through",children:["R$",S.toFixed(2).replace(".",",")]}
)]}
),e.jsxs("p",{
className:"text-xl text-muted-foreground",children:["por ",e.jsxs("span",{
className:"text-6xl font-black text-primary",children:["R$",q.toFixed(2).replace(".",",")]}
)]}
),e.jsxs("p",{
className:"text-sm text-primary font-semibold pt-2",children:["Desconto válido apenas hoje, ",ne(new Date,"dd/MM/yyyy")]}
),e.jsx("p",{
className:"text-sm text-muted-foreground pt-1",children:"Pagamento único • Acesso completo ao programa"}
),e.jsx("p",{
className:"text-sm text-muted-foreground pt-2 font-medium",children:"🔒 Compra 100% Segura • 30 Dias de Garantia Incondicional"}
)]}
)]}
),e.jsx("a",{
href:E,target:"_blank",rel:"noopener noreferrer",className:"w-full bg-primary text-primary-foreground py-4 px-6 rounded-xl font-bold text-lg mb-6 hover:bg-primary/90 transition-colors block text-center animate-pulse-shadow",children:"Obter meu plano personalizado agora"}
),e.jsxs("div",{
className:"mb-6",children:[e.jsx("h2",{
className:"text-xl font-bold text-foreground mb-5 text-center",children:"Resultados que nos deixam orgulhosos"}
),e.jsxs("div",{
className:"space-y-4",children:[e.jsxs("div",{
className:"bg-card rounded-xl overflow-hidden quiz-shadow",children:[e.jsx("img",{
src:oa,alt:"Transformação de Beatriz",className:"w-full object-contain"}
),e.jsxs("div",{
className:"p-4",children:[e.jsx("p",{
className:"font-bold text-primary mb-2",children:"Beatriz: -3kg e Corpo Tonificado em 21 dias"}
),e.jsx("p",{
className:"text-sm text-muted-foreground leading-relaxed",children:`"Eu não estava muito acima do peso, mas meu corpo não tinha forma nenhuma e eu me sentia 'mole'. Com a Calistenia Asiática, a ativação das fibras profundas esculpiu meu corpo. Em 21 dias, perdi 3kg de gordura e minha barriga ficou durinha. Meu corpo finalmente ganhou desenho e me sinto muito mais firme e segura."`}
)]}
)]}
),e.jsxs("div",{
className:"bg-card rounded-xl overflow-hidden quiz-shadow",children:[e.jsx("img",{
src:na,alt:"Transformação de Carla",className:"w-full object-contain"}
),e.jsxs("div",{
className:"p-4",children:[e.jsx("p",{
className:"font-bold text-primary mb-2",children:"Carla: -13kg em 21 dias"}
),e.jsx("p",{
className:"text-sm text-muted-foreground leading-relaxed",children:'"Eu estava perdida, sem energia e com muita vergonha do meu corpo. Achava que precisaria de horas na academia, mas a Calistenia Asiática mudou tudo. Redescobri minha força treinando no meu próprio quarto. Hoje me sinto empoderada, confiante e 13kg mais leve em apenas 3 semanas. Foi a melhor decisão que tomei!"'}
)]}
)]}
),e.jsxs("div",{
className:"bg-card rounded-xl overflow-hidden quiz-shadow",children:[e.jsx("img",{
src:ia,alt:"Transformação de Fernanda",className:"w-full object-contain"}
),e.jsxs("div",{
className:"p-4",children:[e.jsx("p",{
className:"font-bold text-primary mb-2",children:"Fernanda: -4kg em 14 dias"}
),e.jsx("p",{
className:"text-sm text-muted-foreground leading-relaxed",children:`"Sempre fui desconfiada com promessas rápidas, mas as fotos não mentem. Em apenas duas semanas, a ativação das fibras profundas 'sugou' minha barriga para dentro de um jeito que abdominal nenhum fez. Perdi 4kg muito rápido e o inchaço sumiu. Se em 14 dias estou assim, imagina no final do protocolo!"`}
)]}
)]}
),e.jsxs("div",{
className:"bg-card rounded-xl overflow-hidden quiz-shadow",children:[e.jsx("img",{
src:la,alt:"Transformação de Juliana",className:"w-full object-contain"}
),e.jsxs("div",{
className:"p-4",children:[e.jsx("p",{
className:"font-bold text-primary mb-2",children:"Juliana: -8kg em 21 dias (Mãe de 2 filhos)"}
),e.jsx("p",{
className:"text-sm text-muted-foreground leading-relaxed",children:`"Depois da gravidez, essa 'pochete' não saía por nada e minha postura estava horrível. Os movimentos suaves da Calistenia Asiática foram a minha salvação. Recuperei minha postura e eliminei 8kg em 21 dias. Finalmente estou vendo minha barriga ficar retinha de novo, sem precisar de impacto."`}
)]}
)]}
)]}
)]}
),e.jsxs("div",{
className:"bg-card rounded-xl p-5 mb-6 quiz-shadow border-2 border-primary",children:[e.jsxs("div",{
className:"flex items-center justify-center gap-2 mb-3",children:[e.jsx(ce,{
className:"w-4 h-4 text-orange-500"}
),e.jsxs("span",{
className:"text-sm font-semibold text-orange-600",children:["Restam apenas ",f," vagas"]}
)]}
),e.jsxs("div",{
className:"text-center space-y-1",children:[e.jsxs("p",{
className:"text-xl text-muted-foreground",children:["De ",e.jsxs("span",{
className:"line-through",children:["R$",S.toFixed(2).replace(".",",")]}
)]}
),e.jsxs("p",{
className:"text-xl text-muted-foreground",children:["por ",e.jsxs("span",{
className:"text-6xl font-black text-primary",children:["R$",q.toFixed(2).replace(".",",")]}
)]}
),e.jsxs("p",{
className:"text-sm text-primary font-semibold pt-2",children:["Desconto válido apenas hoje, ",ne(new Date,"dd/MM/yyyy")]}
),e.jsx("p",{
className:"text-sm text-muted-foreground pt-1",children:"Pagamento único • Acesso completo ao programa"}
),e.jsx("p",{
className:"text-sm text-muted-foreground pt-2 font-medium",children:"🔒 Compra 100% Segura • 30 Dias de Garantia Incondicional"}
)]}
)]}
),e.jsx("a",{
href:E,target:"_blank",rel:"noopener noreferrer",className:"w-full bg-primary text-primary-foreground py-4 px-6 rounded-xl font-bold text-lg mb-6 hover:bg-primary/90 transition-colors block text-center animate-pulse-shadow",children:"Obter meu plano personalizado agora"}
),e.jsxs("div",{
className:"bg-card rounded-xl p-5 mb-6 quiz-shadow",children:[e.jsx("h2",{
className:"text-2xl font-bold text-primary mb-3 text-center",children:"+Bônus Exclusivos"}
),e.jsx("p",{
className:"text-sm text-muted-foreground text-center mb-6",children:"Além de você ter acesso às aulas e ao seu plano personalizado, separamos diversos bônus para te ajudar a acelerar o seu processo de emagrecimento rápido:"}
),e.jsxs("div",{
className:"space-y-5",children:[e.jsx("div",{
children:e.jsxs("p",{
className:"text-foreground",children:[e.jsx("span",{
className:"font-bold text-primary",children:"1. Chá Asiático Anticelulite"}
)," - Misture uma planta pouco conhecida com água morna para assistir às celulites sumindo dia após dia."]}
)}
),e.jsx("div",{
children:e.jsxs("p",{
className:"text-foreground",children:[e.jsx("span",{
className:"font-bold text-primary",children:"2. Dieta 100% Personalizada"}
)," - Você terá acesso a diversas receitas para preparar e ver a gordura indo embora muito mais rápido."]}
)}
),e.jsx("div",{
children:e.jsxs("p",{
className:"text-foreground",children:[e.jsx("span",{
className:"font-bold text-primary",children:"3. Cronograma de Alimentação Inteligente"}
)," - O passo a passo completo para manter seu metabolismo acelerado e sua reeducação alimentar."]}
)}
),e.jsx("div",{
children:e.jsxs("p",{
className:"text-foreground",children:[e.jsx("span",{
className:"font-bold text-primary",children:"4. Suporte 24h Todos os Dias"}
)," - Nosso time estará pronto para te ajudar com qualquer dúvida, independente do horário."]}
)}
)]}
)]}
),e.jsxs("div",{
className:"bg-card rounded-xl p-5 mb-6 quiz-shadow border border-border",children:[e.jsx("div",{
className:"flex justify-center mb-4",children:e.jsx("img",{
src:da,alt:"Selo de Garantia 30 Dias",className:"w-32 h-32 object-contain"}
)}
),e.jsx("h3",{
className:"text-xl font-bold text-foreground text-center mb-3",children:"30 Dias de Garantia Incondicional"}
),e.jsx("p",{
className:"text-sm text-muted-foreground text-center mb-3",children:"Nós confiamos tanto nos resultados do Protocolo de Calistenia Asiática que o risco é todo nosso."}
),e.jsx("p",{
className:"text-sm text-muted-foreground text-center mb-3",children:"Você tem 30 dias inteiros para testar o aplicativo e todos os bônus. Se por qualquer motivo você não estiver 100% satisfeita, nós devolveremos todo o seu investimento."}
),e.jsx("p",{
className:"text-sm text-foreground text-center font-semibold",children:"Reembolso total e imediato, sem perguntas e sem complicações."}
)]}
),e.jsxs("div",{
className:"mb-6",children:[e.jsx("h2",{
className:"font-bold text-foreground mb-4",children:"Perguntas frequentes"}
),e.jsx("div",{
className:"space-y-2",children:I.map(x=>e.jsxs("div",{
className:"bg-card rounded-xl overflow-hidden quiz-shadow",children:[e.jsxs("button",{
onClick:()=>m(d===x.id?null:x.id),className:"w-full p-4 flex items-center justify-between text-left",children:[e.jsx("span",{
className:"font-medium text-foreground text-sm",children:x.question}
),d===x.id?e.jsx(Ka,{
className:"w-5 h-5 text-muted-foreground flex-shrink-0"}
):e.jsx(Za,{
className:"w-5 h-5 text-muted-foreground flex-shrink-0"}
)]}
),d===x.id&&e.jsx("div",{
className:"px-4 pb-4",children:e.jsx("p",{
className:"text-sm text-muted-foreground",children:x.answer}
)}
)]}
,x.id))}
)]}
),e.jsx("a",{
href:E,target:"_blank",rel:"noopener noreferrer",className:"w-full bg-primary text-primary-foreground py-4 px-6 rounded-xl font-bold text-lg mb-4 hover:bg-primary/90 transition-colors block text-center animate-pulse-shadow",children:"Obter meu plano personalizado agora"}
),e.jsxs("p",{
className:"text-xs text-muted-foreground text-center",children:[e.jsx("a",{
href:"#",className:"underline",children:"Termos de Serviço"}
)," e"," ",e.jsx("a",{
href:"#",className:"underline",children:"Política de Privacidade"}
)]}
)]}
)]}
)}
)]}
)}
;
export{
So as Step12Limitations,Mo as Step13Comfort,Co as Step14Encouragement,Po as Step15Height,Ao as Step16CurrentWeight,Eo as Step17TargetWeight,zo as Step18Age,an as Step1Age,Oo as Step20Lifestyle,Do as Step21Symptoms,Io as Step23ProfileReady,Ro as Step24Activities,Lo as Step25PreparingPlan,$o as Step26Hydration,Fo as Step27Diet,Xo as Step28Habits,Ho as Step29LifeEvents,uo as Step2SocialProof,Vo as Step30Motivation,Go as Step31Projection,Uo as Step32Loading,Zo as Step33Email,Ko as Step34Offer,xo as Step3CalistheniaExperience,fo as Step3MainGoal,go as Step4AdditionalGoals,po as Step4Nao,ho as Step4Sim,vo as Step5BodyZones,yo as Step5bTargetZones,jo as Step6Education,wo as Step7BodyType,No as Step8DreamBody,ko as Step9FitnessHistory,Qo as StepCommitmentDate,Bo as StepEatingHabits,Wo as StepMealPreferences,Yo as StepMotivationReal,Jo as StepPlanSummary,To as StepSleep,_o as StepTransformation,qo as StepWater}
;


