﻿export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', '*');
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const posthogKey = process.env.POSTHOG_API_KEY || 'phx_Cac6WXZncXX658HzhjGh9koqbT7RDcUjSsBSABoKHsf2Ax9x';
  const projId = process.env.POSTHOG_PROJECT_ID || '587018';
  const url = `https://us.i.posthog.com/api/projects/${projId}/events/?limit=100`;

  try {
    const response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${posthogKey}`,
        'User-Agent': 'Mozilla/5.0'
      }
    });
    const data = await response.json();
    return res.status(200).json(data);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}
